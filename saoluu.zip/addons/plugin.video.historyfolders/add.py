import sys, json, os, xbmcvfs, xbmc
from datetime import datetime

ADDON_ID = "plugin.video.historyfolders"
PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")
HISTORY_FILE = os.path.join(PROFILE, "history.json")

if not xbmcvfs.exists(PROFILE):
    xbmcvfs.mkdirs(PROFILE)

def load_history():
    try:
        if xbmcvfs.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception: pass
    return []

def save_history(history):
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[HistoryFolders:add] save error: {e}", xbmc.LOGERROR)

def add_path(path, label=None):
    if not path: return
    path = path.strip()
    folder_name = os.path.basename(path) or path
    label = label.strip() if label else folder_name
    timestamp = datetime.now().strftime("%d/%m/%Y - %H:%M")
    history = load_history()
    # loại trùng lặp
    history = [h for h in history if h["path"] != path]
    history.insert(0, {"path": path, "label": label, "folder": folder_name, "time": timestamp})
    if len(history) > 50: history = history[:50]
    save_history(history)
    xbmc.log(f"[HistoryFolders:add] Added path: {path} label: {label}", xbmc.LOGINFO)

if len(sys.argv) > 1:
    path_arg = sys.argv[1]
    label_arg = sys.argv[2] if len(sys.argv) > 2 else None
    add_path(path_arg, label_arg)
else:
    xbmc.log("[HistoryFolders:add] No path argument passed", xbmc.LOGWARNING)
