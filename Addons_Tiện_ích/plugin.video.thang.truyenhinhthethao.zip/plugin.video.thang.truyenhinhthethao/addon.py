from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus, urljoin
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from pickle import load, dump
from htmlement import fromstring
import xml.etree.ElementTree as ET
from time import strptime, strftime, mktime, time
from concurrent.futures import ThreadPoolExecutor
from sys import argv
from requests import Session
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
import os, re
addon_url = argv[0]
HANDLE = int(argv[1])
PATH = Addon().getAddonInfo('path')
ICON = Addon().getAddonInfo('icon')
addon_id = Addon().getAddonInfo('id')
searchimg = ICON
nextimg = PATH + 'next.png'
bm = 'https://baomoi.com/'
UA = 'OTT Navigator/1.7.3.3 (Linux; Android 16; Pixel 9 Pro Build/AP4A.251212) ExoPlayerLib/2.19.1'
UAM = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 9.0) AppleWebKit/537.36 (KHTML, like Gecko) 120.0.6099.5/9.0 TV Safari/537.36'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
EPG_URL = 'https://vnepg.site/epg.xml'
localhost_names = {'localhost', '127.0.0.1', '::1'}
sre1 = re.compile(r'\n((http|https|udp|rtp):(.*?)\n)')
sre2 = re.compile(r'[,](?!.*[,])(.*)')
sre3 = re.compile(r'group-title="(.*?)"')
sre4 = re.compile(r'tvg-logo="(.*?)"')
sre5 = re.compile(r'http-user-agent=(.*?)\n')
sre6 = re.compile(r'http-referrer=(.*?)\n')
sre7 = re.compile(r'license_key=(.*?)\n')
sre8 = re.compile(r'tvg-id="(.*?)"')
def addDir(title, logo, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{plot}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UAM,'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def getlinkip(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA,'accept-encoding':'gzip','referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def fu(url):
    with Session() as s:
        s.headers.update({'User-Agent': UA, 'accept-encoding':'gzip'})
    try:
        r = s.get(url, allow_redirects=True)
    except:
        r = s.get(url, allow_redirects=True, verify=False)
    return r.url
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def hlsvtv(idx):
    idp = re.sub(r'.*?vtv\.mediacdn\.vn/', 'https://cdn-videos.vtv.vn/', idx) if 'vtv.mediacdn.vn' in idx else re.search(r'(https?://[^\s"]+[^"\']*)', idx)[1]
    return f'{idp}/master.m3u8'
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, ' '.join(element.itertext()).strip())
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def process_channel(ch, epg_ok, root, now_epoch):
    tvg_id = ch['tvg_id']
    name = ch['name']
    if not epg_ok or not tvg_id:
        ch['lps'] = name
        return ch
    programmes = []
    for prog in root.iterfind(f"./programme[@channel='{tvg_id}']"):
        start_str = prog.attrib['start'][:14]
        stop_str = prog.attrib['stop'][:14]
        start_t = strptime(start_str, "%Y%m%d%H%M%S")
        stop_t = strptime(stop_str, "%Y%m%d%H%M%S")
        start_epoch = mktime(start_t)
        stop_epoch = mktime(stop_t)
        title_el = prog.find('title')
        title = title_el.text.strip() if title_el is not None else ''
        programmes.append({
            'start_epoch': start_epoch,
            'stop_epoch': stop_epoch,
            'start_t': start_t,
            'title': title
        })
    programmes.sort(key=lambda x: x['start_epoch'])
    lps_lines = []
    for i, prog in enumerate(programmes):
        if prog['start_epoch'] <= now_epoch < prog['stop_epoch']:
            lps_lines.append(f"[COLOR yellow]{strftime('%H:%M', prog['start_t'])}[/COLOR] {prog['title']}")
            for next_prog in programmes[i + 1:]:
                lps_lines.append(f"[COLOR yellow]{strftime('%H:%M', next_prog['start_t'])}[/COLOR] {next_prog['title']}")
            break
    ch['lps'] = '\n'.join(lps_lines) if lps_lines else name
    return ch
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timvtv', p=1, key = m)
    endOfDirectory(HANDLE)
def timkiem(query, next_page):
    search_query = quote_plus(query)
    u = f'https://vtv.vn/timelinesearch/{next_page}.htm?type=2&keywords={search_query}&sort=0&time=0'
    resp = getlink(u, u).text
    root = fromstring(resp).iterfind('.//div[@class="box-category-item"]//a[@class="box-category-link-with-avatar img-resize"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        idplay = k.get('href')
        addDir(title, logo, title, 'playvtv', url=idplay, is_folder=False)
    trang = f'{next_page + 1}'
    addDir(f'Trang {trang}', nextimg, trang, 'timvtv', p=trang, key=query)
    endOfDirectory(HANDLE)
def tinthethao():
    u = 'https://thethao.vtv.vn/timeline-detaivideo/trang-1.htm'
    resp = getlink(u, 'https://thethao.vtv.vn/').text
    root = fromstring(resp).iterfind('.//div[@class="box-category-item"]//a[@class="box-category-link-with-avatar img-resize"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        idplay = k.get('href')
        linkplay = urljoin(u, idplay)
        addDir(title, logo, title, 'playvtv', url=linkplay, is_folder=False)
    endOfDirectory(HANDLE)
def tinthethaoon():
    u = 'https://tv-web.api.vinasports.com.vn/api/v2/publish/see-more/events/222/?page_num=1&page_size=24'
    root = getlink(u, 'https://tv.onsports.vn/').json()['data']
    for k in root:
        logo = k['thumbnail_vertical']
        title = k['name']
        linkplay = f'https://livevlive.vtvcab.vn/hls/vod/newonsports/DISTRIBUTE/{k["url"]}/index.m3u8'
        addDir(title, logo, title, 'play', id=linkplay, is_folder=False)
    endOfDirectory(HANDLE)
def baomoi(next_page, idbm=None):
    if idbm is None:
        resp = getlink(bm, bm).text
        idbm = re.search(r'buildId":"(.*?)"', resp)[1]
    url = f'{bm}_next/data/{idbm}/video.json' if next_page==1 else f'{bm}_next/data/{idbm}/video/{next_page}.json'
    kq = getlink(url, bm).json()['pageProps']['resp']['data']['content']['items']
    for k in kq:
        idp = k.get('id', '')
        name = k.get('title', '')
        mota = k.get('description', name)
        logo = k.get('thumbL', '')
        if name:
            addDir(name, logo, mota, 'index_bm', idp = idp, idbm=idbm)
    trang = f'{next_page + 1}'
    addDir(f'Trang {next_page}', nextimg, trang, 'baomoi', p=trang , idbm=idbm)
    endOfDirectory(HANDLE)
def index_bm(idp, idbm):
    url = f'{bm}_next/data/{idbm}/content/detail/{idp}.json'
    kq = getlink(url, bm).json()['pageProps']['resp']['data']['content']
    getjs = kq['bodys']
    for i, k in enumerate(getjs):
        if k['type'] == 'video':
            link = k['content']
            logo = k['poster']
            try:
                name = re.sub(r'<[^>]+>', '', getjs[i + 1]['content'])
            except:
                description = kq['description']
                title = kq['title']
                name = description if description else title
            addDir(name, logo, name, 'play', id=link, is_folder=False)
    endOfDirectory(HANDLE)
def main():
    addDir('...Tìm video...', searchimg, 'Tìm video', 'timkiem')
    addDir('Dự báo thời tiết', ICON, 'Dự báo thời tiết', 'playvtv', url='video/vtv-news/ban-tin-thoi-tiet.htm', is_folder=False)
    addDir('Báo Mới', ICON, 'Tin nóng', 'baomoi', p=2)
    addDir('Tin mới VTV', ICON, 'Tin mới', 'tinmoi_vtvvn', p=1)
    addDir('Tin thể thao VTV', ICON, 'Tin thể thao VTV', 'tinthethao')
    addDir('Tin thể thao OnSport', ICON, 'Tin thể thao OnSport', 'tinthethaoon')
    T = {
        'Xem thể thao 4K': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
        'Truyền hình VMT': 'https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/vmttv',
        'Truyền hình Coocaa': 'https://zaltv.cf/xem/tv',
        'Truyền hình Hội Quán': 'https://raw.githubusercontent.com/hoiquanclick/hoiquan/refs/heads/main/vip.m3u',
        'Truyền hình FPT': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
        'Truyền hình Vietnam': 'https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/vn.m3u',
        'DoVietSy IPTV': 'https://raw.githubusercontent.com/dovietsy/acestreamfb/main/acestreamfb.txt',
        'PhatTai IPTV': 'https://raw.githubusercontent.com/thoike84/iptv-vn/refs/heads/main/phattai84.txt',
        'Ace Sport': 'https://raw.githubusercontent.com/dovietsy/acestreamfb/main/acestreamfb.txt',
        'Live Sport': 'https://livesport.io.vn/easport',
        }
    for k in T:
        addDir(k, ICON, k, 'list_iptv', id=T[k])
    endOfDirectory(HANDLE)
def search():
    query = Dialog().input(u'Nhập từ khóa tìm kiếm ...', type=INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def tinmoi_vtvvn(next_page):
    timestamp = int(time())
    url = f'https://vtv.vn/timelinevideo/{timestamp}/{next_page}.htm'
    resp = getlink(url, url).text
    root = fromstring(resp).iterfind('.//div[@class="box-category-item"]//a[@class="box-category-link-with-avatar img-resize"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = k.get('title')
        play = k.get('href')
        addDir(title, logo, title, 'playvtv', url=play, is_folder=False)
    trang = f'{next_page + 1}'
    addDir(f'Trang {trang}', nextimg, trang, 'tinmoi_vtvvn', p=trang)
    endOfDirectory(HANDLE)
def list_iptv(url):
    with ThreadPoolExecutor(2) as laydata:
        future_m3u = laydata.submit(getlinkip, url, url)
        future_epg = laydata.submit(getlink, EPG_URL, EPG_URL)
        texturl = future_m3u.result().text
        epg_ok = True
        try:
            epg_text = future_epg.result().content
            root = ET.fromstring(epg_text)
        except:
            epg_ok = False
            root = None
    group = re.findall(r'group-title="(.*?)"', texturl)
    if len(group) > 1:
        addDir('TẤT CẢ CÁC KÊNH', ICON, 'All', 'little_iptv', id=url)
        ld = list(dict.fromkeys(group))
        um = []
        um = [k for tk in ld for k in (tk.split(';') if ';' in tk else [tk]) if k != '' and k not in um]
        for p in um:
            addDir(p.strip(), ICON, p, 'info_iptv', id=url, tk=p)
    else:
        ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
        channels = []
        now_epoch = time()
        for kq in ketqua:
            s1 = sre1.search(kq)
            s2 = sre2.search(kq)
            s7 = sre7.search(kq)
            if s1 and s2 and not s7 and (urlparse(s1[1]).hostname or '').lower() not in localhost_names:
                s3 = sre3.search(kq)
                s4 = sre4.search(kq)
                s5 = sre5.search(kq)
                s6 = sre6.search(kq)
                s8 = sre8.search(kq)
                channel = {
                    'group': s3[1].strip() if s3 else 'TỔNG HỢP',
                    'name': s2[1].strip(),
                    'tvg_id': s8[1].strip() if s8 else '',
                    'logo': s4[1].strip() if s4 else ICON,
                    'url': s1[1].strip(),
                    'user_agent': s5[1].strip() if s5 else UA,
                    'referrer': s6[1].strip() if s6 else ''
                }
                channels.append(channel)
        if not channels:
            return []
        with ThreadPoolExecutor(max_workers=len(channels)) as executor:
            result = list(executor.map(lambda ch: process_channel(ch, epg_ok, root, now_epoch), channels))
        for k in result:
            tenm = f"{k['name']} - {k['group']}"
            addDir(tenm, k['logo'], k['lps'], 'play', id=k['url'], ref=k['referrer'], user=k['user_agent'], is_folder=False)
    endOfDirectory(HANDLE)
def info_iptv(url, tk):
    channels = []
    now_epoch = time()
    with ThreadPoolExecutor(2) as laydata:
        future_m3u = laydata.submit(getlinkip, url, url)
        future_epg = laydata.submit(getlink, EPG_URL, EPG_URL)
        texturl = future_m3u.result().text
        epg_ok = True
        try:
            epg_text = future_epg.result().content
            root = ET.fromstring(epg_text)
        except:
            epg_ok = False
            root = None
    ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
    for kq in ketqua:
        s1 = sre1.search(kq)
        s2 = sre2.search(kq)
        s7 = sre7.search(kq)
        if s1 and s2 and any(((not s7 and f'group-title="{tk}"' in kq and ';' not in kq), (tk in kq and ';' in kq))) and (urlparse(s1[1]).hostname or '').lower() not in localhost_names:
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            s8 = sre8.search(kq)
            channel = {
                'name': s2[1].strip(),
                'tvg_id': s8[1].strip() if s8 else '',
                'logo': s4[1].strip() if s4 else ICON,
                'url': s1[1].strip(),
                'user_agent': s5[1].strip() if s5 else UA,
                'referrer': s6[1].strip() if s6 else ''
            }
            channels.append(channel)
    if not channels:
        return []
    with ThreadPoolExecutor(max_workers=len(channels)) as executor:
        result = list(executor.map(lambda ch: process_channel(ch, epg_ok, root, now_epoch), channels))
    for k in result:
        addDir(k['name'], k['logo'], k['lps'], 'play', id=k['url'], ref=k['referrer'], user=k['user_agent'], is_folder=False)
    endOfDirectory(HANDLE)
def little_iptv(url):
    channels = []
    now_epoch = time()
    with ThreadPoolExecutor(2) as laydata:
        future_m3u = laydata.submit(getlinkip, url, url)
        future_epg = laydata.submit(getlink, EPG_URL, EPG_URL)
        texturl = future_m3u.result().text
        epg_ok = True
        try:
            epg_text = future_epg.result().content
            root = ET.fromstring(epg_text)
        except:
            epg_ok = False
            root = None
    ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
    for kq in ketqua:
        s1 = sre1.search(kq)
        s2 = sre2.search(kq)
        s7 = sre7.search(kq)
        if s1 and s2 and not s7 and (urlparse(s1[1]).hostname or '').lower() not in localhost_names:
            s3 = sre3.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            s8 = sre8.search(kq)
            channel = {
                'group': s3[1].strip() if s3 else 'TỔNG HỢP',
                'name': s2[1].strip(),
                'tvg_id': s8[1].strip() if s8 else '',
                'logo': s4[1].strip() if s4 else ICON,
                'url': s1[1].strip(),
                'user_agent': s5[1].strip() if s5 else UA,
                'referrer': s6[1].strip() if s6 else ''
            }
            channels.append(channel)
    if not channels:
        return []
    with ThreadPoolExecutor(max_workers=len(channels)) as executor:
        result = list(executor.map(lambda ch: process_channel(ch, epg_ok, root, now_epoch), channels))
    for k in result:
        tenm = f'{k["name"]} - {k["group"]}'
        addDir(tenm, k['logo'], k['lps'], 'play', id=k['url'], ref=k['referrer'], user=k['user_agent'], is_folder=False)
    endOfDirectory(HANDLE)
def playvtv(u):
    url = urljoin('https://vtv.vn/', u)
    resp = getlink(url, url).text
    vfile = hlsvtv(domhtml(fromstring(resp), './/div[@type="VideoStream"]', attribute='data-vid'))
    linkplay = re.sub(r'\s+', '%20', vfile.strip(), flags=re.UNICODE)
    hdr = f'verifypeer=false&User-Agent={UAM}&Referer=https://vtv.vn/'
    play_item = ListItem(offscreen=True, path=linkplay)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play(link, ref=None, user=None):
    with Session() as s:
        headers = {k: v for k, v in (('Referer', ref), ('User-Agent', user)) if v}
        s.headers.update(headers)
        hdr_parts = (f"{k}={unquote(v) if k=='User-Agent' else v}" for k, v in headers.items())
        try:
            r = s.get(link, timeout=20, stream=True)
        except:
            r = s.get(link, timeout=20, stream=True, verify=False)
            hdr_parts.append('verifypeer=false')
    hdr = '&'.join(hdr_parts) if hdr_parts else None
    ctype = r.headers.get('Content-Type', '')
    url = r.url
    if not 'mpegurl' in ctype and hdr:
        url = f'{url}|{hdr}'
    play_item = ListItem(offscreen=True, path=url)
    if 'mpegurl' in ctype:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        if hdr:
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'search': search,
        'timkiem': find,
        'tinthethao': tinthethao,
        'tinthethaoon': tinthethaoon,
        'baomoi': partial(baomoi, int(params.get('p', 2)), params.get('idbm')),
        'timvtv': partial(timkiem, params.get('key'), int(params.get('p', 1))),
        'index_bm': partial(index_bm, params.get('idp'), params.get('idbm')),
        'tinmoi_vtvvn': partial(tinmoi_vtvvn, int(params.get('p', 1))),
        'list_iptv': partial(list_iptv, params.get('id')),
        'info_iptv': partial(info_iptv, params.get('id'), params.get('tk')),
        'little_iptv': partial(little_iptv, params.get('id')),
        'playvtv': partial(playvtv, params.get('url')),
        'play': partial(play, params.get('id'), params.get('ref'), params.get('user', UA))
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass