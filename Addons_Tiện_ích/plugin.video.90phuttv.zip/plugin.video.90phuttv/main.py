from urllib.parse import urlencode, parse_qsl
from datetime import datetime
import sys, xbmcgui, xbmcplugin, requests, os, re, json
import xbmcaddon, xbmc, urllib.request
import shutil, zipfile
addon = xbmcaddon.Addon()
info_update = "https://www.dropbox.com/scl/fi/ii5dcdnn2x3i9kk4stgg6/ver.txt?rlkey=s2f5u1b1x6ozom342fpmjh6hj&e=1&st=nmurh0r8&dl=1"
download_url = "https://www.dropbox.com/scl/fi/clzeq4gef77sfknuwn2uw/plugin.video.90phuttv.zip?rlkey=conqnudz4btkrq6svkas0zkc5&st=hiido3ka&dl=1"
current_version = addon.getAddonInfo('version')
response = requests.get(info_update, timeout=15)
if response.status_code == 200:
    info_version = response.content.decode('utf-8')
    latest_version = re.search(r'ver: "(.*?)"', info_version)
    latest_version_detail = re.search(r'info: "(.*?)"', info_version)
    if latest_version.group(1) != current_version:
        temp_dir = os.path.join(addon.getAddonInfo('path'), 'temp')
        os.makedirs(temp_dir, exist_ok=True)
        response = requests.get(download_url)
        if response.status_code == 200:
            zip_file = os.path.join(temp_dir, 'update.zip')
            with open(zip_file, 'wb') as f:
                f.write(response.content)
            with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            extracted_dir = os.path.join(temp_dir, addon.getAddonInfo('id'))
            addon_dir = addon.getAddonInfo('path')

            for root, dirs, files in os.walk(extracted_dir):
                for file_name in files:
                    src_file = os.path.join(root, file_name)
                    relative_path = os.path.relpath(src_file, extracted_dir)
                    dest_file = os.path.join(addon_dir, relative_path)
                    dest_dir = os.path.dirname(dest_file)
                    if not os.path.exists(dest_dir):
                        os.makedirs(dest_dir)
                    shutil.move(src_file, dest_file)
            
            shutil.rmtree(temp_dir)
            dialog = xbmcgui.Dialog()
            dialog.ok('Đã cập nhật phiên bản mới!', latest_version_detail.group(1)+'\nVui lòng khởi động lại Kodi để cập nhật có hiệu lực!')
else:
    dialog = xbmcgui.Dialog()
    dialog.ok('Lỗi cập nhật!', 'Kết nối dữ liệu cập nhật không thành công.')

base_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON_PATH = addon.getAddonInfo('path')
def get_url(**kwargs):
    return base_url + '?' + urlencode(kwargs)
menu = [
{
    "name": "CakhiaTV",
    "id": "cakhia",
    "logo": os.path.join(ADDON_PATH, 'icon.cakhia.png'),
    "fanart": os.path.join(ADDON_PATH, 'fanart.cakhia.jpg'),
    "desc": "Tr\u1ef1c ti\u1ebfp b\u00f3ng \u0111\u00e1 CakhiaTV",
},
{
    "name": "SaokeTV",
    "id": "saoke",
    "logo": os.path.join(ADDON_PATH, 'icon.saoke.png'),
    "fanart": os.path.join(ADDON_PATH, 'fanart.saoke.png'),
    "desc": "Tr\u1ef1c ti\u1ebfp b\u00f3ng \u0111\u00e1 SaokeTV",
},
{
    "name": "LuongsonTV",
    "id": "luongson",
    "logo": os.path.join(ADDON_PATH, 'icon.luongson.png'),
    "fanart": os.path.join(ADDON_PATH, 'fanart.luongson.jpg'),
    "desc": "Tr\u1ef1c ti\u1ebfp b\u00f3ng \u0111\u00e1 LuongsonTV",
}
#{
#    "name": "Highlights",
#    "id": "highlights",
#    "logo": os.path.join(ADDON_PATH, 'icon.highlights.jpg'),
#    "fanart": os.path.join(ADDON_PATH, 'fanart.highlights.jpg'),
#    "desc": "Highlights c\u00e1c tr\u1eadn \u0111\u1ea5u t\u00e2m \u0111i\u1ec3m",
#},
#{
#	"name": "Xem l\u1ea1i",
#	"id": "replay",
#	"logo": os.path.join(ADDON_PATH, 'icon.replay.jpg'),
#	"fanart": "",
#	"desc": "Xem l\u1ea1i c\u00e1c tr\u1eadn \u0111\u1ea5u \u0111\u00e3 di\u1ec5n ra",
#	"isfolder": "True"
#}
]

def list_menu(menu):
    for k in menu:
        name = k["name"]
        match = k["id"]
        logo = k["logo"]
        fanart = k["fanart"]
        desc = k["desc"]
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'false')
        url = get_url(action='list_type', link=match)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_cakhia():
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Connection': 'keep-alive'
              }
    api = 'https://api.rkdata.xyz/v1/cakhia/match.html'
    data_match = requests.get(url=api, headers=headers).json()
    for item in data_match['data']['lives']:
        blv = '|BLV: ' + item['blv']['name']
        if not item['blv']['name']:
            blv = ''
        name = item['timeShort']+": "+item['home']['name']+" vs "+item['away']['name']+blv
        match = item['url']
        logo = os.path.join(ADDON_PATH, 'icon.cakhia.png')
        fanart = ""
        desc = item['tournament']['name']
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'false')
        url = get_url(action='cakhia', link=match)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_link_cakhia(link):
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Connection': 'keep-alive'
              }
    api_link = 'https://api.rkdata.xyz/v1/cakhia/match.html'
    data = requests.get(url=api_link, headers=headers).json()
    url = 'http://' + data['data']['baseLink'][0]+link.replace('.html', '')
    data = requests.get(url=url, headers=headers).text
    match1 = re.search(r'\\"links\\":\[(.*?)\]\},', data, re.S)
    if match1:
        data_link = re.search(r'\[\{(.*?)\}\]', match1.group(0))
    if data_link:
        name_link = re.findall(r'name":"(.*?)"', data_link.group(0).replace('\\', ''))
        hls_link = re.findall(r'url":"(.*?)"', data_link.group(0).replace('\\', ''))
        for i in range(len(hls_link)):
            if ".m3u8" in hls_link[i] or ".flv" in hls_link[i]:
                logo = os.path.join(ADDON_PATH, 'icon.cakhia.png')
                name = name_link[i]
                match = hls_link[i]+'|Referer=https://watch.rkplayer.xyz/'
                fanart = ""
                desc = "Link: "+name_link[i]
                list_item = xbmcgui.ListItem(name)
                list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
                list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
                list_item.setProperty("IsPlayable", 'true')
                xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def list_saoke():
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Connection': 'keep-alive'
              }
    web = xbmcaddon.Addon().getSetting('saoke_url')
    temp = requests.get(web).text
    url = re.search(r'web:\["(.*?)"', temp).group(1)
    data_match = requests.get(url=url, headers=headers).text
    html = data_match.split('lives=')[1]
    html = html.split('footer')[0]
    html = html.split('},{_id:')
    for item in html:
        match1 = re.search(r'"(.*?)",nameNoUtf8', item)
        match4 = re.search(r'nameNoUtf8:"(.*?)"', item)
        match2 = re.search(r'hôm nay: (.*?)"', item)
        match3 = re.search(r'",time:(.*?),teamAId', item)
        data_league = item.split('league:{_id')[1]
        match5 = re.search(r',name:"(.*?)"', data_league)
        match6 = re.findall(r'picture:"(.*?)"', item)
        match7 = re.search(r'blv:"(.*?)"', item)
        logo = match6[2]
        if logo == '':
            logo = os.path.join(ADDON_PATH, 'icon.saoke.png')
        time = match3.group(1).split('e')[0]
        if len(time) == 7:
            time += '0'
        time += '00'
        if len(time) == 8:
            time += '00'
        from datetime import datetime
        time = datetime.fromtimestamp(int(time)).strftime('%Hh%M-%d/%m')
        blv = '|BLV: ' + match7.group(1)
        if not match7.group(1):
            blv = ''
        name = time+": "+match2.group(1)+blv
        match = f"{match4.group(1)}-{match1.group(1)}"
        fanart = ""
        desc = match5.group(1)
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'false')
        url = get_url(action='saoke', link=match)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_link_saoke(link):
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Cookie': "_ga=GA1.1.1004931860.1740033531; _ga_CFWC6W7DM6=GS1.1.1740033531.1.1.1740033893.0.0.0; _ga_94F2S8MBTB=GS1.1.1740033532.1.1.1740033893.60.0.0; _ga_5TCQ2TL8D6=GS1.1.1740033532.1.1.1740033893.0.0.0; _ga_F8XK0CVH7G=GS1.1.1740033532.1.1.1740033893.0.0.0; _ga_9PZ2YKK2F0=GS1.1.1740033532.1.1.1740033893.0.0.0; _ga_KNR5JKBZGP=GS1.1.1740033532.1.1.1740033893.0.0.0; _ga_GB6YGTY5MT=GS1.1.1740033532.1.1.1740033893.0.0.0"
              }
    web = xbmcaddon.Addon().getSetting('saoke_url')
    temp = requests.get(web).text
    url = re.search(r'web:\["(.*?)"', temp).group(1)
    api = url+'/'+link+'.html'
    data_match = requests.get(url=api, headers=headers).text
    stream_match = re.search(r"cache:'(.*?)',", data_match).group(1)
    if stream_match:
        data_list = json.loads(stream_match)
        for item in data_list:
            if item['name']:
                logo = os.path.join(ADDON_PATH, 'icon.saoke.png')
                name = item['name']
                match = item['url']+'|Referer=https://sk.mediastation.live/'
                fanart = ""
                desc = "Link: "+item['name']
                list_item = xbmcgui.ListItem(name)
                list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
                list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
                list_item.setProperty("IsPlayable", 'true')
                xbmcplugin.addDirectoryItem(HANDLE, match, list_item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)

def list_luongson():
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3'
              }
    api = 'https://api-ls.cdnokvip.com/api/get-livestream-group'
    data_match = requests.get(url=api, headers=headers).json()
    for item in data_match['value']['datas']:
        time = datetime.fromtimestamp(item['matchTime']).strftime('%Hh%M-%d/%m')
        blv = '|BLV: ' + item['commentator']
        if not item['commentator']:
            blv = ''
        name = time+": "+item['homeName']+" vs "+item['awayName']+blv
        match = item['matchId']
        logo = os.path.join(ADDON_PATH, 'icon.luongson.png')
        fanart = ""
        desc = item['leagueName']
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'false')
        url = get_url(action='luongson', link=match)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_link_luongson(link):
    reff = 'https://ls39.live/'
    origin = 'https://ls39.live'
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Referer': reff
              }
    url = 'https://api-ls.cdnokvip.com/api/match-detail?matchId=' + link
    data = requests.post(url=url, headers=headers, verify=False).json()
    if data:
        logo = os.path.join(ADDON_PATH, 'icon.luongson.png')
        name = data['value']['datas']['homeName']+' vs '+data['value']['datas']['awayName']+' | '+data['value']['datas']['commentator']
        match = data['value']['datas']['linkLive']
        fanart = ""
        desc = data['value']['datas']['leagueName']
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'true')
        list_item.setProperty("inputstream", "inputstream.adaptive")
        list_item.setProperty("inputstream.adaptive.manifest_type", "hls")
        list_item.setPath(match)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=match, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def list_highlights():
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Connection': 'keep-alive'
              }
    api = 'https://api.vebo.xyz/api/news/vebotv/list/highlight/1'
    data_match = requests.get(url=api, headers=headers).json()
    for item in data_match['data']['list']:
        if item['category']['slug'] == 'soi-keo':
            pass
        else:
            logo = item['feature_image']
            name = item['name']
            match = item['id']
            fanart = ""
            desc = item['name']
            list_item = xbmcgui.ListItem(name)
            list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
            list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
            list_item.setProperty("IsPlayable", 'true')
            url = get_url(action='highlights', link=match)
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    api2 = 'https://api.vebo.xyz/api/news/vebotv/list/highlight/2'
    data_match = requests.get(url=api2, headers=headers).json()
    for item in data_match['data']['list']:
        if item['category']['slug'] == 'soi-keo':
            pass
        else:
            logo = item['feature_image']
            name = item['name']
            match = item['id']
            fanart = ""
            desc = item['name']
            list_item = xbmcgui.ListItem(name)
            list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
            list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
            list_item.setProperty("IsPlayable", 'true')
            url = get_url(action='highlights', link=match)
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    api3 = 'https://api.vebo.xyz/api/news/vebotv/list/highlight/3'
    data_match = requests.get(url=api3, headers=headers).json()
    for item in data_match['data']['list']:
        if item['category']['slug'] == 'soi-keo':
            pass
        else:
            logo = item['feature_image']
            name = item['name']
            match = item['id']
            fanart = ""
            desc = item['name']
            list_item = xbmcgui.ListItem(name)
            list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
            list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
            list_item.setProperty("IsPlayable", 'true')
            url = get_url(action='highlights', link=match)
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_highlights(link):
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'Connection': 'keep-alive'
              }
    api = 'https://api.vebo.xyz/api/news/vebotv/detail/'+link
    data_match = requests.get(url=api, headers=headers).json()
    match = data_match['data']['video_url']
    list_item = xbmcgui.ListItem('PlayStream', path=match)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

def list_replay():
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'referer': 'https://t5c2.bdhub.link/'
              }
    api = 'https://t5c2.bdhub.link/xem-lai'
    data_match = requests.get(url=api, headers=headers).text
    stream = re.findall(r'container mb-3(.*?)<\/section>', data_match, re.DOTALL)
    for i in range(len(stream)):
    	type_match = re.search(r'5px;" \>(.*?)\<', stream[i])
    	if type_match:
    		name = type_match.group(1).replace('&nbsp; ', '')
    		match = i
    		logo = ""
    		fanart = ""
    		desc = type_match.group(1).replace('&nbsp; ', '')
    		list_item = xbmcgui.ListItem(name)
    		list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
    		list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
    		list_item.setProperty("IsPlayable", 'false')
    		url = get_url(action='replay', link=match)
    		xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_link_replay(link):
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'referer': 'https://t5c2.bdhub.link/'
              }
    api = 'https://t5c2.bdhub.link/xem-lai'
    data_match = requests.get(url=api, headers=headers).text
    stream = re.findall(r'container mb-3(.*?)<\/section>', data_match, re.DOTALL)
    row = stream[int(link)]
    type_match = re.search(r'5px;" \>(.*?)\<', row, re.DOTALL)
    match1 = re.findall(r'" href="(.*?)"', row)
    match2 = re.findall(r'data-src="https(.*?)"', row)
    match3 = re.findall(r'news-title"\>(.*?)\<', row)
    for i in range(len(match1)):
        name = match3[i]
        match = match1[i]
        logo = 'http'+match2[i]
        fanart = ""
        desc = match3[i]
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': fanart})
        list_item.setInfo(type='video', infoLabels={'title': name,'sorttitle': name,'plot': desc})
        list_item.setProperty("IsPlayable", 'true')
        url = get_url(action='play_replay', link=match)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_replay(link):
    headers = {
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3',
              'referer': 'https://t5c2.bdhub.link/'
              }
    reff = get_reff_90phut()
    api = 'https://t5c2.bdhub.link'+urllib.parse.unquote(link)
    data_match = requests.get(url=api, headers=headers).text
    play = re.search(r'link=(.*?)&amp;', data_match)
    match = urllib.parse.unquote(play.group(1))+'|Referer='+reff
    list_item = xbmcgui.ListItem('PlayStream', path=match)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)


def router(string):
    params = dict(parse_qsl(string))
    if not params:
        list_menu(menu)
    elif params['action'] == 'list_type':
        if params['link'] == '90phut':
            list_90phut()
        elif params['link'] == 'thapcam':
            list_thapcam()
        elif params['link'] == 'cakhia':
            list_cakhia()
        elif params['link'] == 'luongson':
            list_luongson()
        elif params['link'] == 'saoke':
            list_saoke()
        elif params['link'] == 'highlights':
            list_highlights()
        elif params['link'] == 'replay':
        	list_replay()

    elif params['action'] == '90phut':
        list_link_90phut(params['link'])
    elif params['action'] == 'thapcam':
        list_link_thapcam(params['link'])
    elif params['action'] == 'cakhia':
        list_link_cakhia(params['link'])
    elif params['action'] == 'luongson':
        list_link_luongson(params['link'])
    elif params['action'] == 'saoke':
        list_link_saoke(params['link'])
    elif params['action'] == 'replay':
        list_link_replay(params['link'])
    elif params['action'] == 'play_replay':
    	play_replay(params['link'])
    elif params['action'] == 'highlights':
        play_highlights(params['link'])


    else:
        raise ValueError(f'Invalid paramstring: {string}!')

if __name__ == '__main__':
    router(sys.argv[2][1:])