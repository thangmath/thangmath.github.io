from future.moves.urllib.request import urlopen


def shorten(aUrl):
    tinyurl = 'http://tinyurl.com/api-create.php?url='
    req = urlopen(tinyurl + aUrl)
    data = req.read()
    return data