1. Thêm đường dẫn thư mục gốc của máy ở cột bên phải.
2. Thêm link https://thangmath.github.io ở cột bên trái. Vào link rồi mở file Android (hoặc file media nếu là TV LG).
3. Bấm giữ vào thư mục duy nhất trong file --> Copy (Sao chép) --> Yes (Có)
4. Copy xong buộc phải bấm nút home ra ngoài màn hình chính, buộc dừng ứng dụng bằng cách giữ nút home rồi đóng,... (hoặc cục súc thì rút điện TV)
   (Không được thoát ứng dụng bằng nút back. Sẽ làm nhiều file bị bộ nhớ đệm trả lại)
5. Vậy là giao diện được cài đặt sẵn, đầy đủ link tha hồ cài addons. Giờ cài app Phim4k sẽ xem được luôn nhé :). Vào tiện ích cập nhật Vietnamese... là hết bị cá nhân hoá giao diện nha.
6. Nếu bạn muốn sao lưu, hãy copy ngược lại từ thư mục gốc 2 thư mục addons \& userdata là được nhé! Khi nào cài thì copy đè ngược lại (nhưng rất dễ làm thừa file gây nặng máy).
   Chỉ nên sao lưu 3, 4, 5 file và nén lại như mình thôi !!!

   Có thể dùng các link trong Trình quản lý file để Sao chép trên mây các file apk về máy để cập nhật lên bản mới nhất (Trong thư mục nightlies ấy nhé!). Hoặc copy cài luôn file ferraridownload để cài nhiều bản mod hay.

