import sys
import json
from urllib import request, parse
from urllib.parse import urlencode, parse_qsl, urlparse
from urllib.request import Request, urlopen, HTTPError
import ssl
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import time
import os
import re
import random

# ===== Biến môi trường Kodi =====
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = dict(parse.parse_qsl(sys.argv[2][1:]))
ADDON_GLOBAL_CATEGORY = "IPTVJSON"

# ===== PHIM4K GLOBALS =====
addon = xbmcaddon.Addon()
API_BASE_URL = "https://kodi.phim4k.xyz/rest-api/v130"
USERNAME = addon.getSetting('username')
PASSWORD = addon.getSetting('password')
COOKIE_FILE = xbmcvfs.translatePath('special://temp/phim4k_cookie.txt')
ssl_ctx = None
if ssl:
    try:
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE
    except:
        ssl_ctx = None

# ===== IPTVJSON GLOBALS =====
DEFAULT_REMOTE_URL = "https://raw.githubusercontent.com/p4kxyz/p4kxyz.github.io/main/kodi.json"
URL_DS_NGUON_REMOTE = "https://raw.githubusercontent.com/p4kxyz/p4kxyz.github.io/main/kodi.json"
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP1A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Dart/3.9 (dart:io) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
IMAGE_GENERATOR_URL = "https://iptv.cameraddns.net/kodi/svg/image_generator.php"
IMAGE_GENERATOR_SEARCH_RESULT = "https://iptv.cameraddns.net/kodi/svg/image_search_result.php"
IMAGE_GENERATOR_NEXTPAGE = "https://iptv.cameraddns.net/kodi/svg/image_nextpage.php"
KT_SEARCH = 50
SET_SIZE_KEY = 50
_DANH_SACH_NGUON_CACHE = None

# Danh sách nguồn đã lọc và thêm Phim4K VIP
DANH_SACH_NGUON_MACDINH = [
    ("phim4k_vip", "phim4k_vip", "", "Phim4K VIP - Kho phim chất lượng cao (Cần đăng nhập)"),
    ("thvli",   "https://iptv.cameraddns.net","", "Phim Tổng Hợp - THVLi. Ứng dụng được LUKAHAI làm ra"),
    ("buncha",    "https://hxcv.site/buncha","", "Bún Chả TV - Trang web phát sóng bóng đá trực tuyến miễn phí hàng đầu tại Việt Nam"),
    ("fpt",     "https://iptv.nhadai.org/v1","", "FPT PLAY - Hệ thống kênh truyền hình trực tuyến đỉnh cao"),
    ("vtvgo",   "https://vtvgo.4share.me","", "VTVgo là sản phẩm của VTV"),
    ("custom",  None,"", "URL JSON tùy chỉnh của bạn. Hãy nhập url tại Configure Addon"),
]

# Hình ảnh mặc định
fallback_img = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path') + '/resources/media/fallback.jpg')
fallback_fanart = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path') + '/resources/media/fallback_fanart.jpg')

# =================================================================================================
# ==================================== PHIM4K FUNCTIONS ===========================================
# =================================================================================================

def get_url(**kwargs):
    return '{}?{}'.format(base_url, urlencode(kwargs))

def get_auth_url():
    parsed = urlparse(API_BASE_URL)
    return "{}://{}/_auth/login".format(parsed.scheme, parsed.netloc)

def login():
    # Reload settings in case user just entered them
    global USERNAME, PASSWORD
    USERNAME = 'thang'
    PASSWORD = '1234'
        
    auth_url = get_auth_url()
    data = urlencode({'username': USERNAME, 'password': PASSWORD}).encode('utf-8')
    headers = {
        'User-Agent': 'Kodi-Phim4K-Oxoo/1.0',
        'Accept': 'application/json'
    }
    
    xbmc.log("Phim4K: Logging in to " + auth_url, xbmc.LOGINFO)
    
    try:
        req = Request(auth_url, data=data, headers=headers)
        with urlopen(req, context=ssl_ctx) as response:
            try:
                body = response.read().decode('utf-8')
                resp_data = json.loads(body)
                if resp_data.get('success') and resp_data.get('session_id'):
                    session_id = resp_data.get('session_id')
                    with open(COOKIE_FILE, 'w') as f:
                        f.write(session_id)
                    xbmc.log("Phim4K: Login successful", xbmc.LOGINFO)
#                    xbmcgui.Dialog().notification('Phim4K VIP', 'Đăng nhập thành công', xbmcgui.NOTIFICATION_INFO)
                    return True
            except:
                pass

            cookie_header = response.info().get('Set-Cookie')
            if cookie_header:
                match = re.search(r'PHIM4K_SESSION=([^;]+)', cookie_header)
                if match:
                    session_id = match.group(1)
                    with open(COOKIE_FILE, 'w') as f:
                        f.write(session_id)
                    xbmc.log("Phim4K: Login successful", xbmc.LOGINFO)
#                    xbmcgui.Dialog().notification('Phim4K VIP', 'Đăng nhập thành công', xbmcgui.NOTIFICATION_INFO)
                    return True
    except Exception as e:
        xbmc.log("Phim4K: Login failed: " + str(e), xbmc.LOGERROR)
#        xbmcgui.Dialog().notification('Phim4K Login Error', str(e), xbmcgui.NOTIFICATION_ERROR)
        
    return True

def get_stored_session():
    if os.path.exists(COOKIE_FILE):
        with open(COOKIE_FILE, 'r') as f:
            return f.read().strip()
    return None

def make_api_request(endpoint, params=None):
    if params is None:
        params = {}
    
    headers = {
        'User-Agent': 'Kodi-Phim4K-Oxoo/1.0'
    }
    
    session_id = get_stored_session()
    if session_id:
        headers['Cookie'] = "PHIM4K_SESSION={}".format(session_id)
    
    url = "{}/{}".format(API_BASE_URL, endpoint)
    if params:
        url += "?" + urlencode(params)
        
    xbmc.log("Phim4K: Calling API: " + url, xbmc.LOGINFO)
    
    try:
        req = Request(url, headers=headers)
        with urlopen(req, context=ssl_ctx) as response:
            data = json.loads(response.read().decode('utf-8'))
            return data
    except HTTPError as e:
        if e.code == 401 or e.code == 403:
            xbmc.log("Phim4K: Auth failed (401/403), trying to login...", xbmc.LOGINFO)
            if login():
                session_id = get_stored_session()
                if session_id:
                    headers['Cookie'] = "PHIM4K_SESSION={}".format(session_id)
                    try:
                        req = Request(url, headers=headers)
                        with urlopen(req, context=ssl_ctx) as response:
                            data = json.loads(response.read().decode('utf-8'))
                            return data
                    except Exception as retry_e:
                        xbmc.log("Phim4K: Retry failed: " + str(retry_e), xbmc.LOGERROR)
        
        xbmc.log("Phim4K: API Error: " + str(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Phim4K Error', str(e), xbmcgui.NOTIFICATION_ERROR)
        return None
    except Exception as e:
        xbmc.log("Phim4K: API Error: " + str(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Phim4K Error', str(e), xbmcgui.NOTIFICATION_ERROR)
        return None

def hien_thi_phim4k_home():
    xbmcplugin.setContent(addon_handle, 'files')
    
    # Check login first
#    if not get_stored_session():
#        if not login():
#            # If login fails, show option to open settings
#            li = xbmcgui.ListItem(label="[Đăng nhập thất bại - Nhấn để mở Cài đặt]")
#            url = get_url(action='open_kodi_settings')
#            xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=False)
#            xbmcplugin.endOfDirectory(addon_handle)
#            return

    # Latest Movies
    li = xbmcgui.ListItem(label="Phim Mới (Latest Movies)")
    url = get_url(action='phim4k_listing', type='movies')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)

    # TV Series
    li = xbmcgui.ListItem(label="Phim Bộ (TV Series)")
    url = get_url(action='phim4k_listing', type='tvseries')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)

    # Genres
    li = xbmcgui.ListItem(label="Thể loại (Genres)")
    url = get_url(action='phim4k_list_genres')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)

    # Countries
    li = xbmcgui.ListItem(label="Quốc gia (Countries)")
    url = get_url(action='phim4k_list_countries')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)

    # Search
    li = xbmcgui.ListItem(label="Tìm kiếm (Search)")
    url = get_url(action='phim4k_search_input')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)
    
    # Back to Source Selection
    li = xbmcgui.ListItem(label="[Đổi Nguồn Dữ Liệu]")
    url = get_url(action='doi_nguon')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def phim4k_list_videos(video_type, page=1):
    endpoint = "movies" if video_type == 'movies' else "tvseries"
    data = make_api_request(endpoint, {'page': page})
    
    if not data:
        xbmcplugin.endOfDirectory(addon_handle)
        return

    videos = []
    if isinstance(data, list):
        videos = data
    elif isinstance(data, dict):
        if 'data' in data: videos = data['data']
        elif 'videos' in data: videos = data['videos']
        elif 'movie' in data: videos = data['movie']
    
    xbmcplugin.setContent(addon_handle, 'movies' if video_type == 'movies' else 'tvshows')
    
    for video in videos:
        vid_id = video.get('videos_id') or video.get('id')
        title = video.get('title', 'Unknown')
        thumb = video.get('poster_url') or video.get('thumbnail_url')
        backdrop = video.get('backdrop_url')
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': backdrop})
        
        info = {
            'title': title,
            'plot': video.get('description'),
            'year': int(video.get('release_year', 0) or video.get('year', 0) or 0),
            'mediatype': 'movie' if video_type == 'movies' else 'tvshow'
        }
        li.setInfo('video', info)

        if video_type == 'movies':
            url = get_url(action='phim4k_play', id=vid_id, type='movie')
            li.setProperty('IsPlayable', 'true')
            is_folder = False
        else:
            url = get_url(action='phim4k_details', id=vid_id, type='tvseries')
            is_folder = True

        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=is_folder)

    # Next page
    li_next = xbmcgui.ListItem(label=">>> Trang tiếp theo ({})".format(page + 1))
    url_next = get_url(action='phim4k_listing', type=video_type, page=page + 1)
    xbmcplugin.addDirectoryItem(addon_handle, url_next, li_next, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def phim4k_show_details(vid_id, vtype, season_id=None):
    data = make_api_request("single_details", {'type': vtype, 'id': vid_id})
    if not data: return

    if vtype == 'tvseries':
        seasons = data.get('season', [])
        if season_id == 'None' or season_id == '': season_id = None
        
        if not season_id:
            xbmcplugin.setContent(addon_handle, 'seasons')
            for season in seasons:
                s_id = season.get('seasons_id')
                s_name = season.get('seasons_name') or "Season {}".format(s_id)
                li = xbmcgui.ListItem(label=s_name)
                li.setInfo('video', {'title': s_name, 'mediatype': 'season'})
                li.setArt({'thumb': data.get('poster_url'), 'fanart': data.get('backdrop_url')})
                url = get_url(action='phim4k_details', id=vid_id, type='tvseries', season_id=s_id)
                xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)
        else:
            xbmcplugin.setContent(addon_handle, 'episodes')
            selected_season = None
            for s in seasons:
                if str(s.get('seasons_id')) == str(season_id):
                    selected_season = s
                    break
            
            if selected_season:
                episodes = selected_season.get('episodes', [])
                for ep in episodes:
                    ep_title = ep.get('episodes_name') or "Episode {}".format(ep.get('episodes_id'))
                    li = xbmcgui.ListItem(label=ep_title)
                    li.setInfo('video', {'title': ep_title, 'mediatype': 'episode'})
                    li.setArt({'thumb': ep.get('image_url')})
                    stream_url = ep.get('file_url')
                    if stream_url:
                        url = get_url(action='phim4k_play_url', url=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)

def phim4k_play_video(vid_id, vtype):
    data = make_api_request("single_details", {'type': vtype, 'id': vid_id})
    if not data: return

    sources = []
    if 'videos' in data and isinstance(data['videos'], list):
        for video in data['videos']:
            url = video.get('file_url')
            if url:
                label = video.get('label') or video.get('file_type', 'Server')
                sources.append({'label': label, 'url': url})

    if not sources:
        url = data.get('stream_url') or data.get('video_url') or data.get('videos_url')
        if url: sources.append({'label': 'Default Server', 'url': url})

    if not sources:
        xbmcgui.Dialog().notification('Lỗi', 'Không tìm thấy link stream', xbmcgui.NOTIFICATION_ERROR)
        return

    stream_url = None
    if len(sources) > 1:
        labels = [s['label'] for s in sources]
        ret = xbmcgui.Dialog().select('Chọn Server / Chất lượng', labels)
        if ret >= 0: stream_url = sources[ret]['url']
        else: return
    else:
        stream_url = sources[0]['url']

    if stream_url:
        play_item = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def phim4k_play_url(url):
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def phim4k_list_genres():
    data = make_api_request("all_genre")
    if not data: return
    genres = data if isinstance(data, list) else []
    for genre in genres:
        li = xbmcgui.ListItem(label=genre.get('name'))
        url = get_url(action='phim4k_listing_filter', type='genre', id=genre.get('genre_id'))
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def phim4k_list_countries():
    data = make_api_request("all_country")
    if not data: return
    countries = data if isinstance(data, list) else []
    for country in countries:
        li = xbmcgui.ListItem(label=country.get('name'))
        url = get_url(action='phim4k_listing_filter', type='country', id=country.get('country_id'))
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def phim4k_list_videos_by_filter(filter_type, filter_id, page=1):
    endpoint = "content_by_genre_id" if filter_type == 'genre' else "content_by_country_id"
    data = make_api_request(endpoint, {'id': filter_id, 'page': page})
    if not data: return

    videos = []
    if isinstance(data, list): videos = data
    elif isinstance(data, dict): videos = data.get('data', [])

    for video in videos:
        vid_id = video.get('videos_id') or video.get('id')
        title = video.get('title', 'Unknown')
        thumb = video.get('poster_url')
        is_tv = video.get('is_tvseries') == '1' or video.get('video_type') == '2'
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb})
        
        if is_tv:
            url = get_url(action='phim4k_details', id=vid_id, type='tvseries')
            is_folder = True
        else:
            url = get_url(action='phim4k_play', id=vid_id, type='movie')
            li.setProperty('IsPlayable', 'true')
            is_folder = False
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=is_folder)
    
    li_next = xbmcgui.ListItem(label=">>> Trang tiếp theo ({})".format(page + 1))
    url_next = get_url(action='phim4k_listing_filter', type=filter_type, id=filter_id, page=page + 1)
    xbmcplugin.addDirectoryItem(addon_handle, url_next, li_next, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def phim4k_search_input():
    keyboard = xbmc.Keyboard('', 'Tìm kiếm phim (Phim4K)')
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query:
            phim4k_perform_search(query)

def phim4k_perform_search(query):
    data = make_api_request("search", {'q': query, 'limit': 20, 'type': 'movie,series'})
    if not data: return
    
    videos = []
    if isinstance(data, list): videos = data
    elif isinstance(data, dict):
        videos = data.get('movie', []) + data.get('tvseries', [])
        if not videos: videos = data.get('data', [])
            
    for video in videos:
        vid_id = video.get('videos_id') or video.get('id')
        title = video.get('title', 'Unknown')
        thumb = video.get('poster_url')
        is_tv = video.get('is_tvseries') == '1' or video.get('video_type') == '2'
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': thumb})
        
        if is_tv:
            url = get_url(action='phim4k_details', id=vid_id, type='tvseries')
            is_folder = True
        else:
            url = get_url(action='phim4k_play', id=vid_id, type='movie')
            li.setProperty('IsPlayable', 'true')
            is_folder = False
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(addon_handle)

# =================================================================================================
# ==================================== IPTVJSON FUNCTIONS =========================================
# =================================================================================================

def thong_bao(tieu_de, noi_dung, level=xbmcgui.NOTIFICATION_INFO, time=3000):
    xbmcgui.Dialog().notification(tieu_de, noi_dung, level, time)

def tai_danh_sach_nguon(url_remote, ds_nguon_mac_dinh):
    xbmc.log(f"[Film Free JSON] Đang tải danh sách nguồn từ: {url_remote}", xbmc.LOGINFO)
    ds_nguon_moi = []
    try:
        data = tai_du_lieu_json(url_remote)
        if not isinstance(data, list): raise Exception("JSON nguồn không phải là danh sách")
        for item in data:
            if not isinstance(item, dict): continue
            ma = item.get('ma') or item.get('key')
            url = item.get('url')
            img = item.get('image')
            mota = item.get('mota') or item.get('description') or ""
            if ma and url:
                # Lọc bỏ các nguồn không mong muốn từ remote nếu cần, nhưng ở đây ta dùng list remote
                # Tuy nhiên, yêu cầu là "xóa các nguồn kkphim, ophim..."
                # Vì list remote có thể chứa chúng, ta có thể lọc ở đây hoặc chỉ dùng list mặc định đã sửa.
                # Để an toàn và tuân thủ yêu cầu "giữ nguyên nguồn API riêng... thêm các nguồn ở addon 2... xóa các nguồn...",
                # Ta sẽ lọc danh sách tải về.
                if ma in ['kkphim', 'ophim', 'nguonc', 'phim4k']:
                    continue
                ds_nguon_moi.append((ma, url, img, mota))
        
        if not ds_nguon_moi: raise Exception("Không phân tích được nguồn nào")
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi tải DS NGUON: {e}. Sử dụng danh sách mặc định.", xbmc.LOGERROR)
        return ds_nguon_mac_dinh

    # Merge với danh sách mặc định (để giữ Phim4K VIP ở đầu và Custom ở cuối)
    # Logic: Phim4K VIP (đầu) + Remote (giữa) + Custom (cuối)
    
    final_list = []
    # 1. Phim4K VIP
    final_list.append(DANH_SACH_NGUON_MACDINH[0])
    
    # 2. Remote List (đã lọc)
    final_list.extend(ds_nguon_moi)
    
    # 3. Custom (tìm trong mặc định)
    for entry in DANH_SACH_NGUON_MACDINH:
        if entry[0] == "custom":
            final_list.append(entry)
            break
            
    return final_list

def duong_dan_profile():
    try: return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    except: return xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

def duong_dan_lich_su():
    path = duong_dan_profile()
    if not xbmcvfs.exists(path): xbmcvfs.mkdirs(path)
    return os.path.join(path, "history.json")

def doc_lich_su():
    file_path = duong_dan_lich_su()
    try:
        if not xbmcvfs.exists(file_path): return []
        f = xbmcvfs.File(file_path, 'r')
        data = f.read(); f.close()
        ds = json.loads(data or "[]")
        return ds if isinstance(ds, list) else []
    except: return []

def ghi_lich_su(ds):
    file_path = duong_dan_lich_su()
    try:
        f = xbmcvfs.File(file_path, 'w')
        f.write(json.dumps(ds, ensure_ascii=False))
        f.close()
    except: pass

def luu_lich_su(muc_ls):
    ds = doc_lich_su()
    remote_url = muc_ls.get('remote_data', {}).get('url')
    source_key = muc_ls.get('source_key')
    if remote_url: khoa_moi = (source_key, remote_url)
    else: khoa_moi = (source_key, muc_ls.get('name'))

    ds_tam = []
    for it in ds:
        it_remote_url = it.get('remote_data', {}).get('url')
        it_source_key = it.get('source_key')
        if it_remote_url: khoa_cu = (it_source_key, it_remote_url)
        else: khoa_cu = (it_source_key, it.get('name'))
        if khoa_cu != khoa_moi: ds_tam.append(it)
    
    ds_tam.insert(0, muc_ls)
    ds_moi = []
    dem = {}
    for it in ds_tam:
        key = it.get('source_key') or 'unknown'
        dem[key] = dem.get(key, 0) + 1
        if dem[key] <= 10: ds_moi.append(it)
    ds_moi.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
    ghi_lich_su(ds_moi)

def xoa_muc_lich_su(index):
    ds = doc_lich_su()
    if index < 0 or index >= len(ds): return
    del ds[index]
    ghi_lich_su(ds)
    thong_bao("Film Free JSON", "Đã xóa khỏi lịch sử")
    hien_thi_lich_su()

def tai_du_lieu_json(url, headers=None):
    final_headers = {'user-agent': UA, 'referer': url}
    if isinstance(headers, dict): final_headers.update(headers)
    for thu in range(3):
        try:
            req = request.Request(url)
            if final_headers:
                for k, v in final_headers.items():
                    try: req.add_header(k, v)
                    except: pass
            with request.urlopen(req, timeout=10) as resp:
                data = resp.read()
            return json.loads(data)
        except Exception as e:
            if thu == 2: raise
            continue

def them_header_vao_url(url_goc, headers):
    if not headers: return url_goc
    header_parts = [f"{k}={v}" for k, v in headers.items() if v]
    return f"{url_goc}|{'&'.join(header_parts)}" if header_parts else url_goc

def chuyen_headers_sang_dict(ds_headers):
    result = {}
    if isinstance(ds_headers, list):
        for it in ds_headers:
            if isinstance(it, dict):
                k = it.get('key'); v = it.get('value')
                if k and v: result[str(k)] = str(v)
    return result

def lay_url_playlist():
    addon = xbmcaddon.Addon()
    custom_url = addon.getSetting("custom_source") or ""
    if custom_url.strip(): return custom_url.strip()
    active_url = addon.getSetting("active_source_url") or ""
    if active_url.strip(): return active_url.strip()
    try:
        fallback_url = DANH_SACH_NGUON_MACDINH[0][1] # phim4k_vip
        addon.setSetting("active_source_url", fallback_url)
        return fallback_url
    except: return ""

def tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=None):
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    thong_bao("Film Free JSON", "Đang tạo playlist phim", xbmcgui.NOTIFICATION_INFO)
    season_num = tim_so_mua(film_name)
    added_count = 0 
    for idx, stream in enumerate(ds_tap):
        media_type = 'episode'
        if len(ds_tap) == 1: media_type = 'movie'
        ds_link = lay_ds_link_tu_tap(stream)
        if not ds_link: continue
        link_chon = chon_link_tot_nhat(ds_link)
        if not link_chon or not link_chon.get('url'): continue
        url_phat = link_chon.get('url')
        headers = link_chon.get('headers') or chuyen_headers_sang_dict(link_chon.get('request_headers'))
        url_kodi = them_header_vao_url(url_phat, headers)
        ep_name = stream.get('name') or f"Tập {idx+1}"
        list_item = xbmcgui.ListItem(label=ep_name)
        list_item.setProperty("IsPlayable", "true")
        list_item.setContentLookup(False)
        list_item_info = list_item.getVideoInfoTag()
        list_item_info.setPlot(desc)
        if media_type == 'movie':
            list_item_info.setMediaType('movie')
            list_item_info.setTitle(film_name) 
        else:
            list_item_info.setMediaType('episode')
            list_item_info.setTitle(ep_name)
            list_item_info.setEpisode(idx + 1)
            list_item_info.setTvShowTitle(film_name)
            if season_num: list_item_info.setSeason(season_num)
            else: list_item_info.setSeason(1)
        try:
            if (link_chon.get('type') or '').lower() == 'hls': list_item.setMimeType('application/x-mpegURL')
        except: pass
        ds_sub_urls = []
        subs = link_chon.get('subtitles') if link_chon else None
        if isinstance(subs, list):
            for sub in subs:
                su = sub.get('url')
                if not su: continue
                sh = sub.get('headers') or chuyen_headers_sang_dict(sub.get('request_headers'))
                ds_sub_urls.append(them_header_vao_url(su, sh) if sh else su)
        if ds_sub_urls:
            try: list_item.setSubtitles(ds_sub_urls)
            except: pass
        playlist.add(url_kodi, list_item)
        added_count += 1
    if added_count == 0:
        thong_bao("Film Free JSON", "Không có nội dung để phát", xbmcgui.NOTIFICATION_ERROR)
        return False
    try: xbmc.Player().play(playlist, startpos=start_index)
    except TypeError: xbmc.Player().play(playlist)
    return True

def phat_truc_tiep(chiso_kenh, chiso_nhom=None):
    try:
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_nhom = playlist.get('groups') or playlist.get('items') or []
        if chiso_nhom is not None and 0 <= chiso_nhom < len(ds_nhom):
            nhom = ds_nhom[chiso_nhom]
            ds_kenh = nhom.get('channels') or nhom.get('items') or []
        else:
            ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if not (0 <= chiso_kenh < len(ds_kenh)): return
        kenh = ds_kenh[chiso_kenh]
        ten_kenh = kenh.get('name') or kenh.get('title') or "Nội dung"
        ds_link = lay_ds_link_tu_tap(kenh)
        if not ds_link: return
        link_chon = chon_link_tot_nhat(ds_link)
        if not link_chon or not link_chon.get('url'): return
        stream_url = link_chon.get('url')
        headers = link_chon.get('headers') or chuyen_headers_sang_dict(link_chon.get('request_headers'))
        url_kodi = them_header_vao_url(stream_url, headers)
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        muc_ls = {
            "name": ten_kenh,
            "timestamp": int(time.time()),
            "type": "full",
            "episode_name": "Full",
            "url_kodi": url_kodi
        }
        if rd and rd.get('url'): muc_ls["remote_data"] = rd
        try:
            addon = xbmcaddon.Addon()
            active_url = (addon.getSetting("active_source_url") or "").strip()
            custom_url = (addon.getSetting("custom_source") or "").strip()
            url_dang_chon = custom_url if custom_url else active_url
            muc_ls["source_key"] = "custom"
            if not custom_url:
                for (ma, url, img, desc) in lay_ds_nguon_da_tai():
                    if url == url_dang_chon:
                        muc_ls["source_key"] = ma
                        break
            if not muc_ls.get("source_key") and lay_ds_nguon_da_tai():
                 muc_ls["source_key"] = lay_ds_nguon_da_tai()[0][0]
        except:
            if lay_ds_nguon_da_tai(): muc_ls["source_key"] = lay_ds_nguon_da_tai()[0][0]
        luu_lich_su(muc_ls)
        item = xbmcgui.ListItem(path=url_kodi, label=ten_kenh)
        item.setProperty("IsPlayable", "true")
        info = item.getVideoInfoTag()
        info.setTitle(ten_kenh)
        info.setPlot(kenh.get('description') or "")
        info.setMediaType('movie')
        ds_sub_urls = []
        subs = link_chon.get('subtitles')
        if isinstance(subs, list):
            for sub in subs:
                su = sub.get('url')
                if not su: continue
                sh = sub.get('headers') or chuyen_headers_sang_dict(sub.get('request_headers'))
                ds_sub_urls.append(them_header_vao_url(su, sh) if sh else su)
        if ds_sub_urls:
            try: item.setSubtitles(ds_sub_urls)
            except: pass
        if (link_chon.get('type') or '').lower() == 'hls':
            try: item.setMimeType('application/x-mpegURL')
            except: pass
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=item)
    except Exception as e:
        thong_bao("Film Free JSON", f"Lỗi phát: {e}", xbmcgui.NOTIFICATION_ERROR)

def hien_thi_menu_du_phong(error_msg):
    xbmcplugin.setContent(addon_handle, 'files')
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    thong_bao("Film Free JSON", f"Lỗi tải nguồn: {error_msg}", xbmcgui.NOTIFICATION_ERROR)
    item_source = xbmcgui.ListItem(label="[Đổi Nguồn Dữ Liệu]", label2="Chọn các nguồn dữ liệu khác")
    img_source = os.path.join(media_path, 'icon_swap.png')
    item_source.setArt({'thumb': img_source, 'icon': img_source}) 
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=doi_nguon", item_source, isFolder=True)
    item_error = xbmcgui.ListItem(label="[LỖI] Nguồn đang lỗi, hãy đổi nguồn khác")
    item_error.setArt({'thumb': os.path.join(media_path, 'icon_error.png'), 'icon': os.path.join(media_path, 'icon_error.png')})
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=doi_nguon", item_error, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def hien_thi_nhom():
    url_playlist = lay_url_playlist()
    
    # ===== PHIM4K VIP CHECK =====
    if url_playlist == "phim4k_vip":
        hien_thi_phim4k_home()
        return
    # ============================

    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    xbmcplugin.setContent(addon_handle, 'movies')
    try:
        playlist = tai_du_lieu_json(url_playlist)
        if not playlist or not isinstance(playlist, dict): raise Exception("Dữ liệu JSON trống hoặc không hợp lệ")
    except Exception as e:
        hien_thi_menu_du_phong(str(e))
        return
        
    ds_nhom = playlist.get('groups') or playlist.get('items') or []
    ds_channels_moi = playlist.get('channels') or []
    load_more = playlist.get('load_more') or []
    if ds_nhom:
        item_source = xbmcgui.ListItem(label="[Đổi Nguồn Dữ Liệu]", label2="Chọn các nguồn dữ liệu khác")
        img_source = os.path.join(media_path, 'icon_swap.png')
        item_source.setArt({'thumb': img_source, 'icon': img_source}) 
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=doi_nguon", item_source, isFolder=True)
        item_search = xbmcgui.ListItem(label="[Tìm kiếm]", label2="Tìm nội dung trong nguồn này")
        img_search = os.path.join(media_path, 'icon_search.png')
        item_search.setArt({'thumb': img_search, 'icon': img_search})
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=search_input", item_search, isFolder=True)
        item_hist = xbmcgui.ListItem(label="[Lịch sử xem]", label2="Xem lịch sử các nội dung đã xem")
        img_hist = os.path.join(media_path, 'icon_history.png')
        item_hist.setArt({'thumb': img_hist, 'icon': img_hist})
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=lich_su_xem", item_hist, isFolder=True)
        item_xem_them = xbmcgui.ListItem(label=">>> Xem thêm Bộ lọc <<<", label2="Duyệt phim theo thể loại, quốc gia...")
        img_filter = tao_hinh_placeholder("Xem thêm Bộ lọc")
        item_xem_them.setArt({'thumb': img_filter, 'icon': img_filter})
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=mo_xem_them", item_xem_them, isFolder=True)
        for idx, nhom in enumerate(ds_nhom):
            ds_channels = nhom.get('channels')
            ten_nhom = nhom.get('name') or nhom.get('title') or f"Group {idx+1}"
            if not ds_channels: continue
            item = xbmcgui.ListItem(label=ten_nhom)
            img_channel = tao_hinh_placeholder(ten_nhom)
            item.setArt({'thumb': img_channel, 'icon': img_channel})
            xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=open_group&g={idx}", item, isFolder=True)
        if ds_channels_moi and load_more:
            tai_noi_dung_moi(ds_channels_moi, load_more)
        ep_view_toan_cuc()
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if not ds_kenh:
            thong_bao("Film Free JSON", "Danh sách trống", xbmcgui.NOTIFICATION_ERROR)
            return
        hien_thi_kenh_theo_danh_sach(ds_kenh, chiso_nhom=None)

def hien_thi_kenh_trong_nhom(chiso_nhom):
    try: playlist = tai_du_lieu_json(lay_url_playlist())
    except Exception as e:
        thong_bao("Film Free JSON", f"Lỗi tải danh sách: {e}", xbmcgui.NOTIFICATION_ERROR)
        return
    ds_nhom = playlist.get('groups') or playlist.get('items') or []
    if chiso_nhom < 0 or chiso_nhom >= len(ds_nhom): return
    nhom = ds_nhom[chiso_nhom]
    ds_kenh = nhom.get('channels') or nhom.get('items') or []
    if not ds_kenh: return
    hien_thi_kenh_theo_danh_sach(ds_kenh, chiso_nhom=chiso_nhom)

def hien_thi_kenh_theo_danh_sach(ds_kenh, chiso_nhom):
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    for idx, kenh in enumerate(ds_kenh):
        loai = (kenh.get('type') or '').lower()
        ten_kenh = kenh.get('name') or kenh.get('title') or f"Channel {idx+1}"
        if loai in ('ad', 'banner'): continue
        logo = None
        if isinstance(kenh.get('image'), str): logo = kenh['image']
        elif isinstance(kenh.get('image'), dict): logo = kenh['image'].get('url')
        if not logo: logo = kenh.get('logo')
        desc = kenh.get('description') or ""
        item = xbmcgui.ListItem(label=ten_kenh, label2=desc)
        info = item.getVideoInfoTag()
        info.setTitle(ten_kenh)
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        if logo: item.setArt({'thumb': logo, 'icon': logo})
        else: item.setArt({'thumb': fallback_img, 'icon': fallback_img})
        if desc: info.setPlot(desc)
        co_stream_truc_tiep = bool(kenh.get('stream') or kenh.get('streams'))
        co_remote = bool(kenh.get('remote_data') or kenh.get('remoteData'))
        co_sources = bool(kenh.get('sources'))
        if co_stream_truc_tiep and not co_remote and not co_sources:
            item.setProperty('IsPlayable', 'true')
            url_play = f"{base_url}?action=play_direct&i={idx}"
            if chiso_nhom is not None: url_play += f"&g={chiso_nhom}"
            xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=False)
        elif co_remote or co_sources:
            url_open = f"{base_url}?action=open_channel&i={idx}"
            if chiso_nhom is not None: url_open += f"&g={chiso_nhom}"
            xbmcplugin.addDirectoryItem(addon_handle, url_open, item, isFolder=True)
        else:
            xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)
    ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

def mo_kenh(chiso_nhom, chiso_kenh):
    try:
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_nhom = playlist.get('groups') or playlist.get('items') or []
        if chiso_nhom is not None and 0 <= chiso_nhom < len(ds_nhom):
            nhom = ds_nhom[chiso_nhom]
            ds_kenh = nhom.get('channels') or nhom.get('items') or []
        else: ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if chiso_kenh < 0 or chiso_kenh >= len(ds_kenh): return
        kenh = ds_kenh[chiso_kenh]
        loai = (kenh.get('type') or '').lower()
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = None
            if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
            data = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data.get('sources') or []
        else: ds_nguon = kenh.get('sources') or []
        if not ds_nguon:
            thong_bao("Film Free JSON", "Không tìm thấy nguồn phát", xbmcgui.NOTIFICATION_ERROR)
            return
        if len(ds_nguon) == 1:
            nguon = ds_nguon[0]
            nguon_name = nguon.get('name') or ""
            ds_tap = lay_ds_tap_tu_nguon(nguon)
            if not ds_tap: return
            film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
            thumb_url = kenh.get('image').get('url') or ""
            desc = kenh.get('description') or ""
            muc_ls = {
                "name": film_name, "thumb_url":thumb_url, "description":desc,
                "timestamp": int(time.time()), "type": loai, "source_index": 0,
                "source_name": nguon_name, "episode_index": 0, "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
            if rd and rd.get('url'): muc_ls["remote_data"] = rd
            try: preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except: preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
            return
        else:
            for i, nguon in enumerate(ds_nguon):
                xbmcplugin.setContent(addon_handle, 'files')
                xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
                film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
                thumb_url = kenh.get('image').get('url') or ""
                desc = kenh.get('description') or ""
                ten = nguon.get('name') or nguon.get('id') or f"Source {i+1}"
                item = xbmcgui.ListItem(label=f"{film_name} - {ten}", label2=desc)
                info = item.getVideoInfoTag()
                info.setTitle(f"{film_name} - {ten}")
                info.setPlot(desc)
                loai_phim = tim_loai_phim(loai)
                info.setMediaType(loai_phim)
                if thumb_url: item.setArt({'thumb': thumb_url, 'icon': thumb_url})
                else: item.setArt({'thumb': fallback_img, 'icon': fallback_img})
                url_mo = f"{base_url}?action=open_source&g={chiso_nhom if chiso_nhom is not None else -1}&i={chiso_kenh}&s={i}"
                xbmcplugin.addDirectoryItem(addon_handle, url_mo, item, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        thong_bao("Film Free JSON", f"Lỗi mở kênh: {e}", xbmcgui.NOTIFICATION_ERROR)

def mo_nguon(chiso_nhom, chiso_kenh, chiso_nguon):
    try:
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_nhom = playlist.get('groups') or playlist.get('items') or []
        if chiso_nhom is not None and 0 <= chiso_nhom < len(ds_nhom):
            nhom = ds_nhom[chiso_nhom]
            ds_kenh = nhom.get('channels') or nhom.get('items') or []
        else: ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if chiso_kenh < 0 or chiso_kenh >= len(ds_kenh): return
        kenh = ds_kenh[chiso_kenh]
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        loai = (kenh.get('type') or '').lower()
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = None
            if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
            data = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data.get('sources') or []
        else: ds_nguon = kenh.get('sources') or []
        if chiso_nguon < 0 or chiso_nguon >= len(ds_nguon): return
        nguon = ds_nguon[chiso_nguon]
        nguon_name = nguon.get('name') or ""
        ds_tap = lay_ds_tap_tu_nguon(nguon)
        if not ds_tap: return
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        muc_ls = {
            "name": film_name, "thumb_url":thumb_url, "description":desc,
            "timestamp": int(time.time()), "type": loai, "source_index": chiso_nguon,
            "source_name":nguon_name, "episode_index": 0, "episode_total": len(ds_tap),
            "episode_name": ds_tap[0].get('name') or "Tập 1"
        }
        if rd and rd.get('url'): muc_ls["remote_data"] = rd
        try: preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
        except: preset_idx = 0
        preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
        luu_lich_su(muc_ls)
        tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
    except Exception as e:
        thong_bao("Film Free JSON", f"Lỗi liệt kê tập: {e}", xbmcgui.NOTIFICATION_ERROR)

def hien_thi_lich_su():
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    ds = doc_lich_su()
    media_path = os.path.join(addon_path, 'resources', 'media')
    item_clear = xbmcgui.ListItem(label="[Xóa lịch sử xem]", label2="Xóa các nội dung đã xem")
    img_clear = os.path.join(media_path, 'icon_clear.png')
    item_clear.setArt({'thumb': img_clear, 'icon': img_clear})
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=xoa_lich_su", item_clear, isFolder=False)
    if not ds:
        thong_bao("Film Free JSON", "Chưa có lịch sử xem.")
        xbmcplugin.endOfDirectory(addon_handle)
        return
    for i, it in enumerate(ds):
        t = it.get('name') or f"Mục {i+1}"
        phu = it.get('description') or ""
        logo = it.get('thumb_url') or ""
        nguon_name = it.get('source_name') or ""
        loai = it.get('type') or ""
        item = xbmcgui.ListItem(label=t, label2=phu)
        item.setArt({'thumb': logo, 'icon': logo})
        info = item.getVideoInfoTag()
        info.setTitle(t)
        info.setPlot(phu)
        info.setGenres([nguon_name])
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        menu_items = []
        menu_items.append(("Xóa khỏi lịch sử", f"RunPlugin({base_url}?action=remove_history_item&i={i})"))
        item.addContextMenuItems(menu_items)
        item.setProperty('IsPlayable', 'true')
        url = f"{base_url}?action=open_history_item&i={i}"
        xbmcplugin.addDirectoryItem(addon_handle, url, item, isFolder=True)
    ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

def mo_lich_su_item(index):
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    xbmcplugin.setContent(addon_handle, 'files')
    ds = doc_lich_su()
    if index < 0 or index >= len(ds): return
    it = ds[index]
    film_name = it.get('name') or "No Name"
    source_index = it.get('source_index', 0)
    ep_index = it.get('episode_index', 0)
    desc = it.get('description') or ""
    loai = it.get('type') or "single"
    thumb_url = it.get('thumb_url') or ""
    rd = it.get('remote_data')
    ds_tap = []
    try:
        if rd and isinstance(rd, dict) and rd.get('url'):
            headers_call = None
            if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
            data = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data.get('sources') or []
            nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
            ds_tap = lay_ds_tap_tu_nguon(nguon)
        else:
            playlist = tai_du_lieu_json(lay_url_playlist())
            ds_nhom = playlist.get('groups') or playlist.get('items') or []
            kenh_tim = None
            for nhom in ds_nhom:
                ds_kenh = nhom.get('channels') or nhom.get('items') or []
                for kenh in ds_kenh:
                    if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                        kenh_tim = kenh; break
                if kenh_tim: break
            if not kenh_tim:
                ds_kenh2 = playlist.get('channels') or playlist.get('items') or []
                for kenh in ds_kenh2:
                    if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                        kenh_tim = kenh; break
            if not kenh_tim: return
            ds_nguon = kenh_tim.get('sources') or []
            nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
            ds_tap = lay_ds_tap_tu_nguon(nguon)
    except: return
    if not ds_tap: return
    
    for j, stream in enumerate(ds_tap):
        ep_playing = it.get('episode_index') or 0
        ep_name = stream.get('name') or f"Tập {j+1}"
        if len(ds_tap) == 1: ep_name = "Full"
        item = xbmcgui.ListItem(label=f"{film_name} - {ep_name}")
        if j == ep_playing: item = xbmcgui.ListItem(label=f"{film_name} - {ep_name} <- Đang Xem")
        info = item.getVideoInfoTag()
        info.setTitle(f"{film_name}")
        info.setPlot(desc)
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        if thumb_url: item.setArt({'thumb': thumb_url, 'icon': thumb_url})
        else: item.setArt({'thumb': fallback_img, 'icon': fallback_img})
        url_play = f"{base_url}?action=play_history_episode&i={index}&e={j}"
        xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def phat_tu_lich_su(index):
    ds = doc_lich_su()
    if index < 0 or index >= len(ds): return
    it = ds[index]
    if it.get('remote_data'):
        film_name = it.get('name') or "Nội dung"
        desc = it.get('description') or ""
        ep_index = it.get('episode_index', 0)
        source_index = it.get('source_index', 0)
        rd = it.get('remote_data')
        ds_tap = []
        try:
            if rd and isinstance(rd, dict) and rd.get('url'):
                headers_call = None
                if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
                elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
                data = tai_du_lieu_json(rd['url'], headers_call)
                ds_nguon = data.get('sources') or []
                nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
                ds_tap = lay_ds_tap_tu_nguon(nguon)
            else:
                playlist = tai_du_lieu_json(lay_url_playlist())
                ds_nhom = playlist.get('groups') or playlist.get('items') or []
                kenh_tim = None
                for nhom in ds_nhom:
                    ds_kenh = nhom.get('channels') or nhom.get('items') or []
                    for kenh in ds_kenh:
                        if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                            kenh_tim = kenh; break
                    if kenh_tim: break
                if not kenh_tim:
                    ds_kenh2 = playlist.get('channels') or playlist.get('items') or []
                    for kenh in ds_kenh2:
                        if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                            kenh_tim = kenh; break
                if not kenh_tim: return
                ds_nguon = kenh_tim.get('sources') or []
                nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
                ds_tap = lay_ds_tap_tu_nguon(nguon)
        except: return
        if not ds_tap: return
        tao_playlist_kodi(ds_tap, film_name, ep_index, desc=desc)
    else: return

def phat_tap_lich_su(index, ep_index):
    ds = doc_lich_su()
    if index < 0 or index >= len(ds): return
    it = ds[index]
    it['episode_index'] = ep_index
    it['episode_name'] = f"Tập {ep_index+1}"
    it['timestamp'] = int(time.time())
    ds[index] = it
    ghi_lich_su(ds)
    phat_tu_lich_su(index)

def get_urlsearchjson(url):
    data = tai_du_lieu_json(url)
    if not isinstance(data, dict): return None, None, None, None
    search = data.get("search") or {}
    if not isinstance(search, dict): return None, None, None, None
    paging = search.get("paging") or {}
    if not isinstance(paging, dict): paging = {}
    url_search = search.get("url")
    search_key = search.get("search_key")
    page_key = paging.get("page_key")
    size_key = paging.get("size_key")
    return url_search, search_key, page_key, size_key

def lay_urlsearch(tu_khoa, trang, kich_thuoc):
    urlnguon = lay_url_playlist()
    obj = get_urlsearchjson(urlnguon)
    base_search = obj[0]
    if not base_search: return None
    qs = parse.urlencode({f"{obj[1]}": tu_khoa, f"{obj[2]}": trang, f"{obj[3]}": kich_thuoc})
    url_search = f"{base_search}?{qs}"
    return url_search

def mo_ket_qua_tim_kiem(tu_khoa, trang, kich_thuoc):
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        if not url_search:
            thong_bao("Film Free JSON", f"Nguồn Này Không Hỗ Trợ Tìm Kiếm", xbmcgui.NOTIFICATION_ERROR)
            return
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or []
        item_home = xbmcgui.ListItem(label="<<< Quay về Trang chủ <<<", label2="Trở về màn hình chính của addon")
        img_home = os.path.join(media_path, 'icon_home.png')
        item_home.setArt({'thumb': img_home, 'logo': img_home})
        xbmcplugin.addDirectoryItem(addon_handle, base_url, item_home, isFolder=True)
        item_title_text = f"Kết quả tìm kiếm: “{tu_khoa}” (Trang {trang})"
        if not ds_kenh: item_title_text = f"Không tìm thấy: {tu_khoa}"
        item_title = xbmcgui.ListItem(label=item_title_text)
        img_item_title = tao_hinh_placeholder(item_title_text,IMAGE_GENERATOR_SEARCH_RESULT)
        item_title.setArt({'thumb': img_item_title, 'icon': img_item_title})
        xbmcplugin.addDirectoryItem(addon_handle, base_url, item_title, isFolder=False)
        for idx, kenh in enumerate(ds_kenh):
            ten_kenh = kenh.get('name') or kenh.get('title') or f"Item {idx+1}"
            loai = (kenh.get('type') or '').lower()
            logo = None
            if isinstance(kenh.get('image'), str): logo = kenh['image']
            elif isinstance(kenh.get('image'), dict): logo = kenh['image'].get('url')
            if not logo: logo = kenh.get('logo')
            desc = kenh.get('description') or ""
            item = xbmcgui.ListItem(label=ten_kenh, label2=desc)
            info = item.getVideoInfoTag()
            info.setTitle(ten_kenh)
            loai_phim = tim_loai_phim(loai)
            info.setMediaType(loai_phim)
            if logo: item.setArt({'thumb': logo, 'icon': logo})
            else: item.setArt({'thumb': fallback_img, 'icon': fallback_img})
            if desc: info.setPlot(desc)
            co_stream_truc_tiep = bool(kenh.get('stream') or kenh.get('streams'))
            co_remote = bool(kenh.get('remote_data') or kenh.get('remoteData'))
            if co_stream_truc_tiep and not co_remote and not kenh.get('sources'):
                item.setProperty('IsPlayable', 'true')
                url_play = f"{base_url}?action=play_direct_search&q={tu_khoa}&p={trang}&s={kich_thuoc}&idx={idx}"
                xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=False)
            elif co_remote or kenh.get('sources'):
                url_open = f"{base_url}?action=open_channel_search&q={tu_khoa}&p={trang}&s={kich_thuoc}&idx={idx}"
                xbmcplugin.addDirectoryItem(addon_handle, url_open, item, isFolder=True)
            else:
                xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)
        page_info = (data.get('load_more') or {}).get('pageInfo') or {}
        current_page = int(page_info.get('current_page') or trang)
        last_page = int(page_info.get('last_page') or current_page)
        if current_page < last_page:
            item_next = xbmcgui.ListItem(label=f"Trang sau ({current_page+1}/{last_page})")
            img_item_next = tao_hinh_placeholder(f"Trang sau ({current_page+1}/{last_page})", IMAGE_GENERATOR_NEXTPAGE)
            item_next.setArt({'thumb': img_item_next, 'icon': img_item_next})
            url_next = f"{base_url}?action=search_next&q={tu_khoa}&p={current_page+1}&s={kich_thuoc}"
            xbmcplugin.addDirectoryItem(addon_handle, url_next, item_next, isFolder=True)
        ep_view_toan_cuc()
        xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        thong_bao("Film Free JSON", f"Lỗi tìm kiếm: {e}", xbmcgui.NOTIFICATION_ERROR)

def mo_channel_tim_kiem(tu_khoa, trang, kich_thuoc, idx):
    xbmcplugin.setContent(addon_handle, 'files')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or []
        if idx < 0 or idx >= len(ds_kenh): return
        kenh = ds_kenh[idx]
        loai = (kenh.get('type') or '').lower()
        ten_kenh = kenh.get('name') or kenh.get('title') or f"Channel {idx+1}"
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if not rd or not rd.get('url'): return
        headers_call = None
        if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
        elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
        jrd = tai_du_lieu_json(rd['url'], headers_call)
        ds_nguon = jrd.get('sources') or []
        if not ds_nguon: return
        for i, nguon in enumerate(ds_nguon):
            ten = nguon.get('name') or nguon.get('id') or f"Source {i+1}"
            thumb_url = kenh.get('image').get('url') or ""
            desc = kenh.get('description') or ""
            item = xbmcgui.ListItem(label=f"{ten_kenh} - {ten}")
            info = item.getVideoInfoTag()
            info.setTitle(f"{ten_kenh} - {ten}")
            info.setPlot(desc)
            loai_phim = tim_loai_phim(loai)
            info.setMediaType(loai_phim)
            if thumb_url: item.setArt({'thumb': thumb_url, 'icon': thumb_url})
            else: item.setArt({'thumb': fallback_img, 'icon': fallback_img})
            url_mo = f"{base_url}?action=open_source_search&q={tu_khoa}&p={trang}&s={kich_thuoc}&idx={idx}&src={i}"
            xbmcplugin.addDirectoryItem(addon_handle, url_mo, item, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)
    except: pass

def mo_source_tim_kiem(tu_khoa, trang, kich_thuoc, idx, src):
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or []
        if idx < 0 or idx >= len(ds_kenh): return
        kenh = ds_kenh[idx]
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if not rd or not rd.get('url'): return
        headers_call = None
        if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
        elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
        jrd = tai_du_lieu_json(rd['url'], headers_call)
        ds_nguon = jrd.get('sources') or []
        if src < 0 or src >= len(ds_nguon): return
        nguon = ds_nguon[src]
        nguon_name = nguon.get('name') or ""
        ds_tap = lay_ds_tap_tu_nguon(nguon)
        if not ds_tap: return
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        muc_ls = {
            "name": film_name, "thumb_url":thumb_url, "description":desc,
            "timestamp": int(time.time()), "type": "series", "source_index": src,
            "source_name": nguon_name, "episode_index": 0, "episode_total": len(ds_tap),
            "episode_name": ds_tap[0].get('name') or "Tập 1"
        }
        if rd and rd.get('url'): muc_ls["remote_data"] = rd
        try: preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
        except: preset_idx = 0
        preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
        luu_lich_su(muc_ls)
        tao_playlist_kodi(ds_tap, film_name, start_index=0)
    except: pass

def phat_truc_tiep_tim_kiem(tu_khoa, trang, kich_thuoc, idx):
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or []
        if idx < 0 or idx >= len(ds_kenh): return
        kenh = ds_kenh[idx]
        st = kenh.get('stream')
        ds_streams = []
        if not st:
            ds_streams = kenh.get('streams') or []
            st = ds_streams[0] if ds_streams else None
        if not st: return
        stream_url = st.get('url')
        headers = st.get('headers') or chuyen_headers_sang_dict(st.get('request_headers'))
        if not stream_url: return
        url_kodi = them_header_vao_url(stream_url, headers)
        ten = kenh.get('name') or kenh.get('title') or "Nội dung"
        loai = (kenh.get('type') or '').lower()
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        muc_ls = {
                "name": ten, "thumb_url":thumb_url, "description":desc,
                "timestamp": int(time.time()), "type": loai, "source_index": 0,
                "episode_index": 0, "episode_total": len(ds_streams),
                "episode_name": ds_streams[0].get('name') or "Tập 1"
            }
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'): muc_ls["remote_data"] = rd
        muc_ls["source_index"] = 0
        try: preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
        except: preset_idx = 0
        preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
        muc_ls["url_kodi"] = url_kodi
        luu_lich_su(muc_ls)
        item = xbmcgui.ListItem(path=url_kodi)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=item)
    except: pass

def phat_tap_tim_kiem(tu_khoa, trang, kich_thuoc, idx, chiso_nguon, chiso_tap):
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or []
        if idx < 0 or idx >= len(ds_kenh): return
        kenh = ds_kenh[idx]
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        headers_call = None
        if rd and rd.get('url'):
            if isinstance(rd.get('headers'), dict): headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list): headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
        else: return
        jrd = tai_du_lieu_json(rd['url'], headers_call)
        ds_nguon = jrd.get('sources') or []
        if chiso_nguon < 0 or chiso_nguon >= len(ds_nguon): return
        nguon = ds_nguon[chiso_nguon]
        ds_tap = []
        contents = nguon.get('contents')
        if isinstance(contents, list):
            for content in contents: ds_tap.extend(content.get('streams') or [])
        elif isinstance(contents, dict): ds_tap.extend(contents.get('streams') or [])
        if not ds_tap: ds_tap.extend(nguon.get('streams') or [])
        if chiso_tap < 0 or chiso_tap >= len(ds_tap): return
        ds_link = ds_tap[chiso_tap].get('stream_links') or []
        if not ds_link: return
        url_phat = None; headers = None
        for link in ds_link:
            if (link.get('type') or '').lower() == 'hls':
                url_phat = link.get('url')
                headers = link.get('headers') or chuyen_headers_sang_dict(link.get('request_headers'))
                if 'no ads' in (link.get('name') or '').lower() or 'noads' in (link.get('name') or '').lower(): break
        if not url_phat:
            link = ds_link[0]
            url_phat = link.get('url')
            headers = link.get('headers') or chuyen_headers_sang_dict(link.get('request_headers'))
        if not url_phat: return
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        loai = (kenh.get('type') or '').lower()
        ep_name = ds_tap[chiso_tap].get('name') or f"Tập {chiso_tap+1}"
        url_kodi = them_header_vao_url(url_phat, headers)
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        muc_ls = {
            "name": film_name, "thumb_url":thumb_url, "description":desc,
            "timestamp": int(time.time()), "type": loai, "source_index": chiso_nguon,
            "episode_index": chiso_tap, "episode_total": len(ds_tap),
            "episode_name": ep_name, "url_kodi": url_kodi
        }
        if rd and rd.get('url'): muc_ls["remote_data"] = rd
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[0][0]
        luu_lich_su(muc_ls)
        item = xbmcgui.ListItem(path=url_kodi)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=item)
    except: pass

def lay_ds_link_tu_tap(episode):
    ds_link = episode.get('stream_links') or []
    if not ds_link:
        rd_ep = episode.get('remote_data') or episode.get('remoteData')
        if rd_ep and rd_ep.get('url'):
            headers_ep = chuyen_headers_sang_dict(rd_ep.get('headers') or rd_ep.get('request_headers'))
            try:
                ep_data = tai_du_lieu_json(rd_ep['url'], headers_ep)
                if isinstance(ep_data, dict):
                    ds_link = ep_data.get('stream_links') or ep_data.get('links') or []
                    if not ds_link and ep_data.get('url'): ds_link = [ep_data]
                elif isinstance(ep_data, list): ds_link = ep_data
            except: ds_link = []
    return ds_link

def lay_ds_tap_tu_nguon(nguon):
    ds_tap = []
    contents = nguon.get('contents')
    if isinstance(contents, list):
        for content in contents: ds_tap.extend(content.get('streams') or [])
    elif isinstance(contents, dict): ds_tap.extend(contents.get('streams') or [])
    if not ds_tap: ds_tap.extend(nguon.get('streams') or [])
    return ds_tap

def chon_link_tot_nhat(ds_link):
    if not ds_link: return None
    def la_noads(name: str) -> bool:
        n = (name or "").lower()
        return ('no ads' in n) or ('noads' in n) or ('không quảng cáo' in n)
    ds_hls = [l for l in ds_link if (l.get('type') or '').lower() == 'hls']
    if ds_hls:
        ds_hls_noads = [l for l in ds_hls if la_noads(l.get('name'))]
        ds_uutien = ds_hls_noads + [l for l in ds_hls if l not in ds_hls_noads]
    else:
        ds_noads = [l for l in ds_link if la_noads(l.get('name'))]
        ds_uutien = ds_noads + [l for l in ds_link if l not in ds_noads]
    for link in ds_uutien:
        if link.get('url'): return link
    if not ds_uutien:
         for link in ds_link:
            if link.get('url'): return link
    return None

def hien_thi_ds_nguon_khac():
    xbmcplugin.setContent(addon_handle, 'files')
    try:
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        nguon_media_path = os.path.join(addon_path, 'resources', 'media', 'nguon')
        custom_url = (addon.getSetting("custom_source") or "").strip()
        active_url = (addon.getSetting("active_source_url") or "").strip()
        url_dang_chon = custom_url if custom_url else active_url
        media_path = os.path.join(addon_path, 'resources', 'media')
        
        for idx, (ma, url, img, desc) in enumerate(lay_ds_nguon_da_tai()):
            ten_nguon = ma.upper()
            logo_path = img
            logo_path_custom = os.path.join(nguon_media_path, f"custom.png") 
            is_active = (url and (url.strip() == url_dang_chon))
            if ma == "custom":
                item_label = "[Nguồn Tùy Chỉnh (Settings)]"
                if custom_url: item_label = f"▶ [Nguồn Tùy Chỉnh] (Đang dùng)"
                item = xbmcgui.ListItem(label=item_label, label2="Nguồn tùy chỉnh của bạn")
                item.setArt({'thumb': logo_path_custom, 'icon': logo_path_custom})
                url_settings = f"{base_url}?action=open_kodi_settings"
                xbmcplugin.addDirectoryItem(addon_handle, url_settings, item, isFolder=False)
            elif is_active:
                item = xbmcgui.ListItem(label=f"▶ {ten_nguon} (Đang dùng)", label2=desc)
                item.setArt({'thumb': logo_path, 'icon': logo_path}) 
                xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)
            else:
                item = xbmcgui.ListItem(label=f"Chuyển sang: {ten_nguon}", label2=desc)
                item.setArt({'thumb': logo_path, 'icon': logo_path})
                url_set = f"{base_url}?action=set_nguon&new_idx={idx}"
                xbmcplugin.addDirectoryItem(addon_handle, url_set, item, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)
    except: pass

def dat_nguon_moi(new_idx):
    try:
        if new_idx < 0 or new_idx >= len(lay_ds_nguon_da_tai()): return
        (ma, url_moi, img, desc) = lay_ds_nguon_da_tai()[new_idx]
        ten_nguon_moi = ma.upper()
        if not url_moi and ma != "phim4k_vip": return # Phim4K VIP has dummy url but it's fine
        addon = xbmcaddon.Addon()
        addon.setSetting("active_source_url", url_moi)
        addon.setSetting("custom_source", "")
        thong_bao("Film Free JSON", f"Đã chuyển nguồn sang: {ten_nguon_moi}. Đang tải lại...")
        xbmc.executebuiltin(f"Container.Update({base_url})")
    except: pass

def open_kodi_settings():
    try:
        addon_id = xbmcaddon.Addon().getAddonInfo('id')
        xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True) 
    except: pass

def tim_loai_phim(loai):
    loai_phim = 'movie'
    if loai == 'single': return loai_phim
    elif loai == 'series': return 'tvshow'
    elif loai == 'playlist': return 'tvshow'
    else: return loai_phim

def lay_ds_nguon_da_tai():
    global _DANH_SACH_NGUON_CACHE
    if _DANH_SACH_NGUON_CACHE is not None: return _DANH_SACH_NGUON_CACHE
    try:
        url_dong = lay_url_remote_config()
        ds_nguon = tai_danh_sach_nguon(url_dong, DANH_SACH_NGUON_MACDINH)
        _DANH_SACH_NGUON_CACHE = ds_nguon
        return _DANH_SACH_NGUON_CACHE
    except:
        _DANH_SACH_NGUON_CACHE = DANH_SACH_NGUON_MACDINH
        return _DANH_SACH_NGUON_CACHE

def tim_so_mua(ten_phim):
    if not ten_phim: return None
    pattern = re.compile(r'(Phần|Mùa|Season)\s*(\d{1,2})', re.IGNORECASE)
    match = pattern.search(ten_phim)
    if match:
        try: return int(match.group(2))
        except ValueError: return None
    return None

def mo_xem_them():
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    try:
        media_path = os.path.join(addon_path, 'resources', 'media')
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_sorts = playlist.get('sorts')
        if not ds_sorts or not isinstance(ds_sorts, list): return
        flat_list = []
        for sort_item in ds_sorts:
            item_type = sort_item.get('type')
            if item_type == 'radio': flat_list.append(sort_item) 
            elif item_type == 'dropdown':
                value_array = sort_item.get('value')
                if isinstance(value_array, list):
                    for sub_item in value_array:
                        if sub_item.get('type') == 'radio': flat_list.append(sub_item)
        if not flat_list: return
        for item_data in flat_list:
            text = item_data.get('text')
            url = item_data.get('url')
            if not text or not url: continue
            item = xbmcgui.ListItem(label=text)
            img_text = tao_hinh_placeholder(text)
            item.setArt({'thumb': img_text, 'icon': img_text})
            url_action = f"{base_url}?action=tai_danh_sach_phan_trang&url={parse.quote_plus(url)}&page=1"
            xbmcplugin.addDirectoryItem(addon_handle, url_action, item, isFolder=True)
        ep_view_toan_cuc()
        xbmcplugin.endOfDirectory(addon_handle)
    except: pass

def tai_danh_sach_phan_trang():
    try:
        base_url_str = parse.unquote(args.get('url'))
        page = int(args.get('page', '1'))
        page_key = args.get('page_key', 'p')
        size_key = args.get('size_key', 's')
        url_parts = list(parse.urlsplit(base_url_str))
        query = dict(parse.parse_qsl(url_parts[3]))
        query[page_key] = page
        query[size_key] = SET_SIZE_KEY
        url_parts[3] = parse.urlencode(query)
        url_to_load = parse.urlunsplit(url_parts)
        data = tai_du_lieu_json(url_to_load)
        ds_kenh = data.get('channels')
        if not ds_kenh or not isinstance(ds_kenh, list):
            xbmcplugin.endOfDirectory(addon_handle)
            return
        hien_thi_kenh_theo_xem_them(ds_kenh, url_to_load, base_url_str, data.get('load_more'))
    except: xbmcplugin.endOfDirectory(addon_handle)

def hien_thi_kenh_theo_xem_them(ds_kenh, url_da_tai, url_goc, load_more_data, home=False):
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    if home == False:
        item_home = xbmcgui.ListItem(label="<<< Quay về Trang chủ <<<", label2="Trở về màn hình chính của addon")
        img_home = os.path.join(media_path, 'icon_home.png')
        item_home.setArt({'thumb': img_home, 'logo': img_home})
        xbmcplugin.addDirectoryItem(addon_handle, base_url, item_home, isFolder=True)
    
    for idx, kenh in enumerate(ds_kenh):
        loai = (kenh.get('type') or '').lower()
        ten_kenh = kenh.get('name') or kenh.get('title') or f"Channel {idx+1}"
        logo = None
        if loai in ('ad', 'banner'): continue
        if isinstance(kenh.get('image'), str): logo = kenh['image']
        elif isinstance(kenh.get('image'), dict): logo = kenh['image'].get('url')
        if not logo: logo = kenh.get('logo')
        desc = kenh.get('description') or ""
        item = xbmcgui.ListItem(label=ten_kenh, label2=desc)
        art_dict = {}
        if logo: art_dict['thumb'] = logo; art_dict['icon'] = logo
        else: art_dict['thumb'] = fallback_img; art_dict['icon'] = fallback_img
        item.setArt(art_dict)
        info = item.getVideoInfoTag()
        info.setTitle(ten_kenh)
        info.setPlot(desc)
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        url_da_tai_encoded = parse.quote_plus(url_da_tai)
        if loai_phim == 'movie':
            item.setProperty('IsPlayable', 'true')
            url_play = f"{base_url}?action=mo_kenh_xem_them&i={idx}&url={url_da_tai_encoded}"
            xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=False)
        elif loai_phim == 'tvshow':
            url_open = f"{base_url}?action=mo_kenh_xem_them&i={idx}&url={url_da_tai_encoded}"
            xbmcplugin.addDirectoryItem(addon_handle, url_open, item, isFolder=True)
        else: xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)

    if isinstance(load_more_data, dict):
        page_info = load_more_data.get('pageInfo', {})
        current_page = int(page_info.get('current_page', 1))
        last_page = int(page_info.get('last_page', current_page))
        next_page = current_page + 1
        if next_page <= last_page:
            paging_keys = load_more_data.get('paging', {})
            page_key_next = paging_keys.get('page_key', 'p')
            size_key_next = paging_keys.get('size_key', 's')
            name_next = (f"Trang sau ({next_page}/{last_page})")
            item_next = xbmcgui.ListItem(label=name_next)
            img_home = tao_hinh_placeholder(name_next, IMAGE_GENERATOR_NEXTPAGE)
            item_next.setArt({'thumb': img_home, 'logo': img_home})
            url_action_next = f"{base_url}?action=tai_danh_sach_phan_trang&url={parse.quote_plus(url_goc)}&page={next_page}&page_key={page_key_next}&size_key={size_key_next}"
            xbmcplugin.addDirectoryItem(addon_handle, url_action_next, item_next, isFolder=True)
    ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

def mo_kenh_xem_them():
    xbmcplugin.setContent(addon_handle, 'files')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    try:
        url_da_tai = parse.unquote(args.get('url'))
        chiso_kenh = int(args.get('i', -1))
        url_da_tai_encoded = parse.quote_plus(url_da_tai)
        if not url_da_tai or chiso_kenh == -1: return
        data = tai_du_lieu_json(url_da_tai)
        ds_kenh = data.get('channels')
        if not ds_kenh or not (0 <= chiso_kenh < len(ds_kenh)): return
        kenh = ds_kenh[chiso_kenh]
        loai = (kenh.get('type') or '').lower()
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = chuyen_headers_sang_dict(rd.get('headers') or rd.get('request_headers'))
            data_kenh = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data_kenh.get('sources') or []
        else: ds_nguon = kenh.get('sources') or []
        if not ds_nguon: return
        if len(ds_nguon) == 1:
            nguon = ds_nguon[0]
            nguon_name = nguon.get('name') or ""
            ds_tap = lay_ds_tap_tu_nguon(nguon)
            if not ds_tap: return
            muc_ls = {
                "name": film_name, "thumb_url":thumb_url, "description":desc,
                "timestamp": int(time.time()), "type": loai, "source_index": 0,
                "source_name":nguon_name, "episode_index": 0, "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
                }
            if rd and rd.get('url'): muc_ls["remote_data"] = rd
            try: preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except: preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
            return
        else:
            xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
            logo = None
            if isinstance(kenh.get('image'), str): logo = kenh['image']
            elif isinstance(kenh.get('image'), dict): logo = kenh['image'].get('url')
            if not logo: logo = kenh.get('logo')
            art_dict = {}
            if logo: art_dict['thumb'] = logo; art_dict['icon'] = logo
            else: art_dict['thumb'] = fallback_img; art_dict['icon'] = fallback_img
            for i, nguon in enumerate(ds_nguon):
                ten_nguon = nguon.get('name') or f"Nguồn {i+1}"
                item_label = f"{film_name} - [{ten_nguon}]"
                item = xbmcgui.ListItem(label=item_label, label2=desc)
                item.setArt(art_dict)
                info = item.getVideoInfoTag()
                info.setTitle(item_label)
                info.setPlot(desc)
                info.setMediaType('tvshow')
                url_action = f"{base_url}?action=mo_nguon_xem_them&i={chiso_kenh}&sc={i}&url={url_da_tai_encoded}"
                xbmcplugin.addDirectoryItem(addon_handle, url_action, item, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle)
    except: pass

def mo_nguon_xem_them():
    try:
        url_da_tai = parse.unquote(args.get('url'))
        chiso_kenh = int(args.get('i', -1))
        chiso_nguon = int(args.get('sc', -1))
        if not url_da_tai or chiso_kenh == -1 or chiso_nguon == -1: return
        data = tai_du_lieu_json(url_da_tai)
        ds_kenh = data.get('channels')
        if not ds_kenh or not (0 <= chiso_kenh < len(ds_kenh)): return
        kenh = ds_kenh[chiso_kenh]
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = chuyen_headers_sang_dict(rd.get('headers') or rd.get('request_headers'))
            data_kenh = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data_kenh.get('sources') or []
        else: ds_nguon = kenh.get('sources') or []
        if not ds_nguon or not (0 <= chiso_nguon < len(ds_nguon)): return
        nguon = ds_nguon[chiso_nguon]
        nguon_name = nguon.get('name') or ""
        ds_tap = lay_ds_tap_tu_nguon(nguon)
        if not ds_tap: return
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        loai = (kenh.get('type') or '').lower()
        muc_ls = {
                "name": film_name, "thumb_url":thumb_url, "description":desc,
                "timestamp": int(time.time()), "type": loai, "source_index": chiso_nguon,
                "source_name":nguon_name, "episode_index": 0, "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
        if rd and rd.get('url'): muc_ls["remote_data"] = rd
        try: preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
        except: preset_idx = 0
        preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
        luu_lich_su(muc_ls)
        tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
        return
    except: pass

def cap_nhat_view_toan_cuc():
    try:
        window_id = xbmcgui.getCurrentWindowId()
        if not window_id: return
        window = xbmcgui.Window(window_id)
        focus_id = window.getFocusId()
        current_view_id = str(focus_id)
        if not current_view_id.isdigit() or int(current_view_id) >= 1000: return
        if not current_view_id.isdigit() or int(current_view_id) <= 50: return
        addon = xbmcaddon.Addon()
        saved_view_id = addon.getSetting('global_view_id')
        if current_view_id != saved_view_id:
            addon.setSetting('global_view_id', current_view_id)
    except: pass

def ep_view_toan_cuc():
    try:
        addon = xbmcaddon.Addon()
        saved_view_id = addon.getSetting('global_view_id')
        if saved_view_id and saved_view_id.isdigit():
            xbmc.executebuiltin(f"Container.SetViewMode({saved_view_id})")
    except: pass

def tao_hinh_placeholder(text, link=IMAGE_GENERATOR_URL):
    try:
        if not IMAGE_GENERATOR_URL or "myserver.com" in IMAGE_GENERATOR_URL: return fallback_img 
        encoded_text = parse.quote_plus(text.upper())
        final_url = f"{link}?text={encoded_text}"
        return final_url
    except: return fallback_img

def lay_url_remote_config():
    addon = xbmcaddon.Addon()
    setting_url = addon.getSetting("remote_source_url")
    if setting_url and setting_url.strip(): return setting_url.strip()
    return DEFAULT_REMOTE_URL

def tai_noi_dung_moi(ds_kenh, load_more):
    try:
        base_url_str = load_more.get('remote_data').get('url')
        page = '1'
        paging = load_more.get('paging')
        page_key = paging.get('page_key')
        size_key = paging.get('size_key')
        url_parts = list(parse.urlsplit(base_url_str))
        query = dict(parse.parse_qsl(url_parts[3]))
        query[page_key] = page
        query[size_key] = 50
        url_parts[3] = parse.urlencode(query)
        url_to_load = parse.urlunsplit(url_parts)
        if not ds_kenh or not isinstance(ds_kenh, list):
            xbmcplugin.endOfDirectory(addon_handle)
            return
        hien_thi_kenh_theo_xem_them(ds_kenh, url_to_load, base_url_str, load_more, home=True)
    except: xbmcplugin.endOfDirectory(addon_handle)

def main():
    try:
        action = args.get('action')
        actions_from_home = [ 
            'open_source', 'mo_nguon_xem_them', 'set_nguon', 'doi_nguon',
            'open_history_item', 'play_history_episode', 'open_channel_search',
            'phim4k_listing', 'phim4k_details', 'phim4k_play', 'phim4k_play_url', 'phim4k_search'
        ]
        if action not in actions_from_home and action is not None:
            cap_nhat_view_toan_cuc()
        
        if action is None: hien_thi_nhom(); return

        # ===== PHIM4K ACTIONS =====
        if action == 'phim4k_listing':
            phim4k_list_videos(args.get('type'), int(args.get('page', 1))); return
        if action == 'phim4k_details':
            phim4k_show_details(args.get('id'), args.get('type'), args.get('season_id')); return
        if action == 'phim4k_play':
            phim4k_play_video(args.get('id'), args.get('type')); return
        if action == 'phim4k_play_url':
            phim4k_play_url(args.get('url')); return
        if action == 'phim4k_search_input':
            phim4k_search_input(); return
        if action == 'phim4k_list_genres':
            phim4k_list_genres(); return
        if action == 'phim4k_list_countries':
            phim4k_list_countries(); return
        if action == 'phim4k_listing_filter':
            phim4k_list_videos_by_filter(args.get('type'), args.get('id'), int(args.get('page', 1))); return
        # ==========================

        if action == 'doi_nguon': hien_thi_ds_nguon_khac(); return
        if action == 'set_nguon': new_idx = int(args.get('new_idx', -1)); dat_nguon_moi(new_idx); return
        if action == 'open_kodi_settings': open_kodi_settings(); return
        if action == 'open_group': g = int(args.get('g', -1)); hien_thi_kenh_trong_nhom(g); return
        if action == 'open_channel': g = int(args.get('g', -1)); i = int(args.get('i', -1)); mo_kenh(g if g >= 0 else None, i); return
        if action == 'open_source': g = int(args.get('g', -1)); i = int(args.get('i', -1)); s = int(args.get('s', -1)); mo_nguon(g if g >= 0 else None, i, s); return
        if action == 'play_direct': i = int(args.get('i', -1)); g = int(args.get('g', -1)) if 'g' in args else None; phat_truc_tiep(i, g); return
        if action == 'lich_su_xem': hien_thi_lich_su(); return
        if action == 'xoa_lich_su': ghi_lich_su([]); thong_bao("Film Free JSON", "Đã xóa toàn bộ lịch sử."); xbmc.executebuiltin("Container.Refresh"); return
        if action == 'play_from_history': idx = int(args.get('i', -1)); phat_tu_lich_su(idx); return
        if action == 'open_history_item': idx = int(args.get('i', -1)); mo_lich_su_item(idx); return
        if action == 'remove_history_item': idx = int(args.get('i', -1)); xoa_muc_lich_su(idx); xbmc.executebuiltin("Container.Refresh"); return
        if action == 'play_history_episode': idx = int(args.get('i', -1)); ep = int(args.get('e', -1)); phat_tap_lich_su(idx, ep); return
        if action == 'search_input':
            tu_khoa = xbmcgui.Dialog().input("Nhập từ khóa", type=xbmcgui.INPUT_ALPHANUM)
            if not tu_khoa: return
            mo_ket_qua_tim_kiem(tu_khoa, 1, KT_SEARCH); return
        if action == 'search_next':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            mo_ket_qua_tim_kiem(tu_khoa, trang, kich_thuoc); return
        if action == 'open_channel_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            mo_channel_tim_kiem(tu_khoa, trang, kich_thuoc, idx); return
        if action == 'open_source_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            src = int(args.get('src', '-1'))
            mo_source_tim_kiem(tu_khoa, trang, kich_thuoc, idx, src); return
        if action == 'play_direct_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            phat_truc_tiep_tim_kiem(tu_khoa, trang, kich_thuoc, idx); return
        if action == 'play_episode_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            src = int(args.get('src', '-1'))
            ep = int(args.get('ep', '-1'))
            phat_tap_tim_kiem(tu_khoa, trang, kich_thuoc, idx, src, ep); return
        if action == 'mo_xem_them': mo_xem_them(); return
        if action == 'tai_danh_sach_phan_trang': tai_danh_sach_phan_trang(); return
        if action == 'mo_kenh_xem_them': mo_kenh_xem_them(); return
        if action == 'mo_nguon_xem_them': mo_nguon_xem_them(); return

        hien_thi_nhom()
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi router: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi: {e}", xbmcgui.NOTIFICATION_ERROR)

if __name__ == "__main__":
    main()