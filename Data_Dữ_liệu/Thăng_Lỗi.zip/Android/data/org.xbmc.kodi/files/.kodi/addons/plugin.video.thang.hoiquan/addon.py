from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from requests import Session
from pickle import dumps, loads
from base64 import b64encode, b64decode
from collections import defaultdict
from htmlement import fromstring
from time import time
from sys import argv
from xbmcgui import ListItem
import re
addon_url = argv[0]
HANDLE = int(argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
nextimg = RESOURCES + 'next.png'
UA = ''
linkiptv = 'https://raw.githubusercontent.com/hoiquanclick/hoiquan/refs/heads/main/vip.m3u'
def addDir(title, logo, mode, is_folder=True, **kwargs):
    kwargs = {key: b64encode(dumps(value)).decode('utf-8') if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=f'{title}')
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(f'{title}')
    info_tag.setPlot(f'{title}')
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    with Session() as s:
        s.headers.update({'user-agent': UA, 'referer': ref.encode('utf-8')})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def remove_html_tags(text):
    return re.sub(r'<[^>]*>', '', text)
def convert_to_gmt7(time_str):
    hour, minute = map(int, time_str.split(":"))
    time_gmt7 = (hour + 7) % 24
    return f"{time_gmt7:02}:{minute:02}"
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, ' '.join(element.itertext()).strip())
def fu(url):
    with Session() as s:
        s.headers.update({'user-agent': UA, 'referer': url.encode('utf-8')})
        try:
            r = s.get(url, allow_redirects=True)
        except:
            r = s.get(url, allow_redirects=True, verify=False)
    return r.url
class m3u:
    @staticmethod
    def convert(m3u_file: str):
        m3u_json = []
        lines = m3u_file.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("#EXTINF"):
                channelInfo = {}
                try:
                    logoStartIndex = line.index('tvg-logo="') + 10
                    logoEndIndex = line.index('"', logoStartIndex)
                    logoUrl = line[logoStartIndex:logoEndIndex]
                except ValueError:
                    logoUrl = ""
                try:
                    groupTitleStartIndex = line.index('group-title="') + 13
                    groupTitleEndIndex = line.index('"', groupTitleStartIndex)
                    groupTitle = line[groupTitleStartIndex:groupTitleEndIndex]
                except ValueError:
                    groupTitle = ""
                titleStartIndex = line.rindex(",") + 1
                title = line[titleStartIndex:].strip() if "," in line else ""
                j = i + 1
                link = ""
                user_agent = ""
                referrer = ""
                while j < len(lines) and lines[j].startswith("#"):
                    if lines[j].startswith("#EXTVLCOPT:http-user-agent="):
                        user_agent = lines[j].split("=", 1)[1].strip()
                    elif lines[j].startswith("#EXTVLCOPT:http-referrer="):
                        referrer = lines[j].split("=", 1)[1].strip()
                    j += 1
                if j < len(lines):
                    link = lines[j].strip()
                channelInfo["tvg-logo"] = logoUrl
                channelInfo["group-title"] = groupTitle
                channelInfo["title"] = title
                channelInfo["link"] = link
                if referrer:
                    channelInfo["referrer"] = referrer
                m3u_json.append(channelInfo)
            i += 1
        return m3u_json
def play(link, ref=None):
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
    linkplay = fu(link.split('|')[0]) if '|' in link else fu(link)
    if ref:
        hdr += f'&Referer={ref}/'
    if 'm3u8' in linkplay:
        play_item = ListItem(offscreen=True, path=linkplay)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        play_item = ListItem(offscreen=True, path=f'{linkplay}|{hdr}')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def main():
    m3u_json = m3u.convert(getlink(linkiptv, linkiptv).text)
    ld = []
    seen = set()
    for k in m3u_json:
        nhom = k['group-title']
        if nhom not in seen:
            seen.add(nhom)
            ld.append(nhom)
    for k in ld:
        addDir(k, ICON, 'group', nhom = k)
    endOfDirectory(HANDLE)
def group(nhom):
    m3u_json = m3u.convert(getlink(linkiptv, linkiptv).text)
    for k in m3u_json:
        if nhom == k['group-title']:
            logo = k.get('tvg-logo', ICON)
            name = k['title'].strip()
            link = k['link']
            referrer = k.get('referrer')
            addDir(name, logo, 'play', link = link, ref=referrer, is_folder=False)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'group': partial(group, params.get('nhom')),
        'play': partial(play, params.get('link'), params.get('ref')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass